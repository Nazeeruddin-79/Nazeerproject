const router = require('express').Router()
const { z } = require('zod')
const controller = require('../controllers/lessonController')
const { protect, allowRoles } = require('../middleware/auth')
const { videoUpload } = require('../middleware/upload')
const validate = require('../middleware/validate')
const asyncHandler = require('../utils/asyncHandler')

const schema = z.object({
  title: z.string().trim().min(2).max(140),
  description: z.string().trim().max(3000).optional(),
  order: z.coerce.number().int().min(1),
  durationMinutes: z.coerce.number().min(0).max(10000).optional(),
  videoUrl: z.string().url().or(z.literal('')).optional(),
  isPreview: z
    .union([z.boolean(), z.enum(['true', 'false'])])
    .transform((value) => value === true || value === 'true')
    .optional()
})

router.post(
  '/course/:courseId',
  protect,
  allowRoles('instructor'),
  videoUpload,
  validate(schema),
  asyncHandler(controller.create)
)

router.get('/:lessonId/video', protect, asyncHandler(controller.stream))

router.post(
  '/:lessonId/complete',
  protect,
  allowRoles('student'),
  asyncHandler(controller.complete)
)

router.get('/:lessonId', protect, asyncHandler(controller.get))

router.patch(
  '/:lessonId',
  protect,
  allowRoles('instructor'),
  videoUpload,
  validate(schema.partial()),
  asyncHandler(controller.update)
)

router.delete(
  '/:lessonId',
  protect,
  allowRoles('instructor'),
  asyncHandler(controller.remove)
)

module.exports = router
