import { API_URL, TOKEN_KEY } from '../config'

export function getAuthToken() {
  return localStorage.getItem(TOKEN_KEY)
}

export function setAuthToken(token) {
  localStorage.setItem(TOKEN_KEY, token)
}

export function clearAuthToken() {
  localStorage.removeItem(TOKEN_KEY)
}

export async function apiRequest(endpoint, options = {}) {
  const token = getAuthToken()
  const isFormData = options.body instanceof FormData

  const headers = {
    ...(isFormData ? {} : { 'Content-Type': 'application/json' }),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers
  }

  let response

  try {
    response = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers
    })
  } catch {
    throw new Error(
      'Cannot reach the Learning Hub server. Check that the backend is running and VITE_API_URL is correct.'
    )
  }

  const contentType = response.headers.get('content-type') || ''
  const data = contentType.includes('application/json')
    ? await response.json()
    : null

  if (response.status === 401) {
    clearAuthToken()
  }

  if (!response.ok) {
    const message =
      data?.message ||
      (Array.isArray(data?.errors) && data.errors[0]?.message) ||
      `Request failed (${response.status}).`
    const error = new Error(message)
    error.status = response.status
    throw error
  }

  return data || {}
}

/**
 * The video endpoint accepts the JWT as a query parameter because a native
 * <video> element cannot send an Authorization header.
 */
export function authorizedVideoUrl(streamPath) {
  if (!streamPath) return ''
  const origin = API_URL.replace(/\/api$/, '')
  const token = getAuthToken()
  const separator = streamPath.includes('?') ? '&' : '?'
  return `${origin}${streamPath}${separator}token=${encodeURIComponent(token || '')}`
}

export const authApi = {
  login: (data) =>
    apiRequest('/auth/login', { method: 'POST', body: JSON.stringify(data) }),
  register: (data) =>
    apiRequest('/auth/register', { method: 'POST', body: JSON.stringify(data) }),
  me: () => apiRequest('/auth/me')
}

export const courseApi = {
  list: (query = '') => apiRequest(`/courses${query}`),
  get: (id) => apiRequest(`/courses/${id}`),
  mine: () => apiRequest('/courses/mine'),
  create: (data) =>
    apiRequest('/courses', { method: 'POST', body: JSON.stringify(data) }),
  update: (id, data) =>
    apiRequest(`/courses/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data)
    }),
  remove: (id) => apiRequest(`/courses/${id}`, { method: 'DELETE' }),
  enroll: (id) => apiRequest(`/courses/${id}/enroll`, { method: 'POST' })
}

export const lessonApi = {
  create: (courseId, formData) =>
    apiRequest(`/lessons/course/${courseId}`, {
      method: 'POST',
      body: formData
    }),
  update: (id, formData) =>
    apiRequest(`/lessons/${id}`, { method: 'PATCH', body: formData }),
  remove: (id) => apiRequest(`/lessons/${id}`, { method: 'DELETE' }),
  complete: (id) => apiRequest(`/lessons/${id}/complete`, { method: 'POST' })
}

export const quizApi = {
  mine: () => apiRequest('/quizzes/mine'),
  forCourse: (courseId) => apiRequest(`/quizzes/course/${courseId}`),
  get: (id) => apiRequest(`/quizzes/${id}`),
  create: (courseId, data) =>
    apiRequest(`/quizzes/course/${courseId}`, {
      method: 'POST',
      body: JSON.stringify(data)
    }),
  update: (id, data) =>
    apiRequest(`/quizzes/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data)
    }),
  remove: (id) => apiRequest(`/quizzes/${id}`, { method: 'DELETE' }),
  submit: (id, answers) =>
    apiRequest(`/quizzes/${id}/submit`, {
      method: 'POST',
      body: JSON.stringify({ answers })
    }),
  attempts: () => apiRequest('/quizzes/attempts/mine')
}

export const studentApi = {
  dashboard: () => apiRequest('/student/dashboard'),
  courses: () => apiRequest('/student/courses'),
  lessons: (courseId) => apiRequest(`/student/courses/${courseId}/lessons`),
  progress: () => apiRequest('/student/progress'),
  quizzes: () => apiRequest('/student/quizzes')
}

export const instructorApi = {
  dashboard: () => apiRequest('/instructor/dashboard'),
  students: () => apiRequest('/instructor/students'),
  courseLessons: (courseId) =>
    apiRequest(`/instructor/courses/${courseId}/lessons`)
}
