import { useEffect, useMemo, useState } from 'react'
import {
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Clock3,
  Download,
  Eye,
  FileQuestion,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Trash2,
  UploadCloud,
  Users,
  Video,
  X
} from 'lucide-react'
import { Link, useSearchParams } from 'react-router-dom'
import { EmptyState, ErrorState, LoadingState } from '../components/States'
import ProgressBar from '../components/ProgressBar'
import { useApi } from '../hooks/useApi'
import {
  courseApi,
  instructorApi,
  lessonApi,
  quizApi
} from '../services/api'
import {
  courseColor,
  courseEmoji,
  formatDate,
  formatDateTime,
  formatMinutes
} from '../utils/ui'

function PageHeading({ eyebrow, title, description, action }) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        {description && <p className="muted">{description}</p>}
      </div>
      {action}
    </div>
  )
}

function StatusPill({ status }) {
  const published = status === 'published'
  return (
    <span className={`status-pill ${published ? 'pass' : 'neutral'}`}>
      {published ? 'Published' : 'Draft'}
    </span>
  )
}

export function InstructorDashboard() {
  const { data, loading, error, reload } = useApi(instructorApi.dashboard, [])
  const dashboard = data?.dashboard

  if (loading) return <LoadingState message="Loading your teaching space..." />
  if (error) return <ErrorState message={error} onRetry={reload} />

  const courses = dashboard?.courses || []
  const attempts = dashboard?.recentAttempts || []

  return (
    <>
      <PageHeading
        eyebrow="YOUR TEACHING SPACE ✦"
        title="Make an impact, one lesson at a time."
        description="Here's what's happening in your classroom."
        action={
          <Link to="/instructor/create-course" className="button button-primary">
            <Plus size={17} /> Create a course
          </Link>
        }
      />

      <div className="stats-grid">
        <div className="stat-card">
          <span className="stat-icon lilac">
            <BookOpen />
          </span>
          <div>
            <strong>{dashboard?.courseCount ?? 0}</strong>
            <small>Courses created</small>
          </div>
          <span className="stat-foot">
            {dashboard?.publishedCount ?? 0} published
          </span>
        </div>
        <div className="stat-card">
          <span className="stat-icon peach">
            <Users />
          </span>
          <div>
            <strong>{dashboard?.studentCount ?? 0}</strong>
            <small>Total students</small>
          </div>
          <span className="stat-foot">Growing community</span>
        </div>
        <div className="stat-card">
          <span className="stat-icon mint">
            <Video />
          </span>
          <div>
            <strong>{dashboard?.lessonCount ?? 0}</strong>
            <small>Video lessons</small>
          </div>
          <span className="stat-foot">Ready to learn</span>
        </div>
        <div className="stat-card">
          <span className="stat-icon yellow">
            <FileQuestion />
          </span>
          <div>
            <strong>{dashboard?.quizCount ?? 0}</strong>
            <small>Quizzes</small>
          </div>
          <span className="stat-foot">
            {dashboard?.quizAttemptCount ?? 0} attempts
          </span>
        </div>
      </div>

      <div className="section-row">
        <div>
          <h2>Your courses</h2>
          <p className="muted">Manage the learning experiences you've created.</p>
        </div>
        <Link to="/instructor/courses" className="text-link">
          Manage all <ArrowRight size={16} />
        </Link>
      </div>

      {courses.length ? (
        <div className="instructor-course-list">
          {courses.slice(0, 5).map((course) => (
            <div className="instructor-course-row" key={course.id}>
              <div className={`mini-course-art ${courseColor(course.id)}`}>
                {courseEmoji(course.category)}
              </div>
              <div className="instructor-course-info">
                <strong>{course.title}</strong>
                <span>
                  {course.category} · {course.lessonCount} lesson
                  {course.lessonCount === 1 ? '' : 's'} ·{' '}
                  {course.studentCount} student
                  {course.studentCount === 1 ? '' : 's'}
                </span>
              </div>
              <StatusPill status={course.status} />
              <Link
                className="button button-outline button-small"
                to={`/instructor/lessons?course=${course.id}`}
              >
                Lessons
              </Link>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          title="No courses yet"
          description="Create your first course and start sharing what you know."
          action={
            <Link
              to="/instructor/create-course"
              className="button button-primary button-small"
            >
              Create a course <ArrowRight size={16} />
            </Link>
          }
        />
      )}

      {attempts.length > 0 && (
        <>
          <div className="section-row section-row-spaced">
            <div>
              <h2>Recent quiz attempts</h2>
              <p className="muted">How your students are doing right now.</p>
            </div>
            <Link to="/instructor/students" className="text-link">
              All students <ArrowRight size={16} />
            </Link>
          </div>
          <div className="table-panel">
            <div className="table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>Student</th>
                    <th>Quiz</th>
                    <th>Score</th>
                    <th>Result</th>
                    <th>Submitted</th>
                  </tr>
                </thead>
                <tbody>
                  {attempts.map((attempt) => (
                    <tr key={attempt.id}>
                      <td>
                        <strong>{attempt.studentName}</strong>
                        <small>{attempt.studentEmail}</small>
                      </td>
                      <td>
                        <strong>{attempt.quizTitle}</strong>
                        <small>{attempt.courseTitle}</small>
                      </td>
                      <td>{attempt.percentage}%</td>
                      <td>
                        <span
                          className={`status-pill ${
                            attempt.passed ? 'pass' : 'fail'
                          }`}
                        >
                          {attempt.passed ? 'Passed' : 'Not passed'}
                        </span>
                      </td>
                      <td>{formatDateTime(attempt.submittedAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </>
  )
}

export function ManageCourses() {
  const { data, loading, error, reload } = useApi(courseApi.mine, [])
  const [busyId, setBusyId] = useState('')
  const [message, setMessage] = useState('')
  const [actionError, setActionError] = useState('')

  const courses = data?.courses || []

  async function toggleStatus(course) {
    setBusyId(course.id)
    setActionError('')
    setMessage('')
    try {
      const nextStatus = course.status === 'published' ? 'draft' : 'published'
      await courseApi.update(course.id, { status: nextStatus })
      setMessage(
        `"${course.title}" is now ${nextStatus === 'published' ? 'published' : 'a draft'}.`
      )
      reload()
    } catch (err) {
      setActionError(err.message)
    } finally {
      setBusyId('')
    }
  }

  async function removeCourse(course) {
    const confirmed = window.confirm(
      `Delete "${course.title}"? Lessons, enrollments, quiz attempts and quizzes for this course will also be deleted.`
    )
    if (!confirmed) return

    setBusyId(course.id)
    setActionError('')
    setMessage('')
    try {
      await courseApi.remove(course.id)
      setMessage(`"${course.title}" was deleted.`)
      reload()
    } catch (err) {
      setActionError(err.message)
    } finally {
      setBusyId('')
    }
  }

  if (loading) return <LoadingState message="Loading your courses..." />
  if (error) return <ErrorState message={error} onRetry={reload} />

  return (
    <>
      <PageHeading
        eyebrow="YOUR CONTENT"
        title="Manage courses"
        description="Publish, update or remove the courses you have created."
        action={
          <Link to="/instructor/create-course" className="button button-primary">
            <Plus size={17} /> New course
          </Link>
        }
      />

      {message && (
        <p className="success-message" role="status">
          {message}
        </p>
      )}
      {actionError && (
        <p className="error-message" role="alert">
          {actionError}
        </p>
      )}

      {courses.length ? (
        <div className="instructor-course-list">
          {courses.map((course) => (
            <div className="instructor-course-row" key={course.id}>
              <div className={`mini-course-art ${courseColor(course.id)}`}>
                {courseEmoji(course.category)}
              </div>
              <div className="instructor-course-info">
                <strong>{course.title}</strong>
                <span>
                  {course.category} · {course.level} · {course.lessonCount} lesson
                  {course.lessonCount === 1 ? '' : 's'} · {course.studentCount}{' '}
                  student{course.studentCount === 1 ? '' : 's'}
                </span>
              </div>
              <StatusPill status={course.status} />
              <div className="row-actions">
                <Link
                  className="icon-button"
                  title="Manage lessons"
                  aria-label={`Manage lessons for ${course.title}`}
                  to={`/instructor/lessons?course=${course.id}`}
                >
                  <Video size={17} />
                </Link>
                <Link
                  className="icon-button"
                  title="Manage quizzes"
                  aria-label={`Manage quizzes for ${course.title}`}
                  to={`/instructor/quizzes?course=${course.id}`}
                >
                  <FileQuestion size={17} />
                </Link>
                <button
                  type="button"
                  className="button button-outline button-small"
                  disabled={busyId === course.id}
                  onClick={() => toggleStatus(course)}
                >
                  {course.status === 'published' ? 'Unpublish' : 'Publish'}
                </button>
                <button
                  type="button"
                  className="icon-button danger"
                  title="Delete course"
                  aria-label={`Delete ${course.title}`}
                  disabled={busyId === course.id}
                  onClick={() => removeCourse(course)}
                >
                  <Trash2 size={17} />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          title="You haven't created any courses yet"
          description="Your first course only takes a title, a short description and a few lessons."
          action={
            <Link
              to="/instructor/create-course"
              className="button button-primary button-small"
            >
              Create a course <ArrowRight size={16} />
            </Link>
          }
        />
      )}
    </>
  )
}

export function CreateCourse() {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState('Development')
  const [level, setLevel] = useState('Beginner')
  const [thumbnail, setThumbnail] = useState('')
  const [status, setStatus] = useState('draft')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [created, setCreated] = useState(null)

  async function handleCreateCourse(event) {
    event.preventDefault()
    setError('')
    setCreated(null)

    if (title.trim().length < 3) {
      setError('Course title must contain at least 3 characters.')
      return
    }

    if (description.trim().length < 10) {
      setError('Description must contain at least 10 characters.')
      return
    }

    setSaving(true)

    try {
      const data = await courseApi.create({
        title: title.trim(),
        description: description.trim(),
        category,
        level,
        thumbnail: thumbnail.trim(),
        status
      })

      setCreated(data.course)
      setTitle('')
      setDescription('')
      setCategory('Development')
      setLevel('Beginner')
      setThumbnail('')
      setStatus('draft')
    } catch (err) {
      setError(err.message || 'Could not create course.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <>
      <PageHeading
        eyebrow="SHARE WHAT YOU KNOW"
        title="Create a course"
        description="Start with the big idea. You can add lessons next."
      />

      <form className="form-panel" onSubmit={handleCreateCourse}>
        <label>
          Course title
          <input
            required
            minLength={3}
            maxLength={140}
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="e.g. Introduction to web design"
            disabled={saving}
          />
        </label>

        <label>
          Short description
          <textarea
            required
            minLength={10}
            maxLength={5000}
            rows={4}
            value={description}
            onChange={(event) => setDescription(event.target.value)}
            placeholder="What will students learn in this course?"
            disabled={saving}
          />
        </label>

        <div className="field-row">
          <label>
            Category
            <select
              value={category}
              onChange={(event) => setCategory(event.target.value)}
              disabled={saving}
            >
              <option>Development</option>
              <option>Design</option>
              <option>Business</option>
              <option>Personal growth</option>
              <option>Data</option>
              <option>Artificial Intelligence</option>
            </select>
          </label>

          <label>
            Level
            <select
              value={level}
              onChange={(event) => setLevel(event.target.value)}
              disabled={saving}
            >
              <option>Beginner</option>
              <option>Intermediate</option>
              <option>Advanced</option>
            </select>
          </label>
        </div>

        <label>
          Thumbnail URL (optional)
          <input
            type="url"
            value={thumbnail}
            onChange={(event) => setThumbnail(event.target.value)}
            placeholder="https://example.com/course-cover.jpg"
            disabled={saving}
          />
        </label>

        <label>
          Course status
          <select
            value={status}
            onChange={(event) => setStatus(event.target.value)}
            disabled={saving}
          >
            <option value="draft">Save as draft</option>
            <option value="published">Publish course</option>
          </select>
        </label>

        {error && (
          <p className="error-message" role="alert">
            {error}
          </p>
        )}
        {created && (
          <div className="success-panel" role="status">
            <CheckCircle2 size={20} />
            <div>
              <strong>Course created: {created.title}</strong>
              <span>
                Add lessons and videos now, or come back any time from My courses.
              </span>
              <div className="success-actions">
                <Link
                  to={`/instructor/lessons?course=${created.id}`}
                  className="button button-primary button-small"
                >
                  Add lessons <ArrowRight size={16} />
                </Link>
                <Link
                  to="/instructor/courses"
                  className="button button-outline button-small"
                >
                  Manage courses
                </Link>
              </div>
            </div>
          </div>
        )}

        <div className="form-actions">
          <button type="submit" className="button button-primary" disabled={saving}>
            {saving ? 'Saving course...' : 'Save course'}
            {!saving && <ArrowRight size={17} />}
          </button>
        </div>
      </form>
    </>
  )
}

export function ManageLessons() {
  const [searchParams] = useSearchParams()
  const coursesRequest = useApi(courseApi.mine, [])
  const courses = coursesRequest.data?.courses || []

  const [selectedCourse, setSelectedCourse] = useState('')
  const [editingId, setEditingId] = useState('')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [order, setOrder] = useState('1')
  const [durationMinutes, setDurationMinutes] = useState('')
  const [isPreview, setIsPreview] = useState(false)
  const [selectedFile, setSelectedFile] = useState(null)
  const [fileInputKey, setFileInputKey] = useState(0)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const [busyLessonId, setBusyLessonId] = useState('')

  const lessonsRequest = useApi(
    () =>
      selectedCourse
        ? instructorApi.courseLessons(selectedCourse)
        : Promise.resolve(null),
    [selectedCourse]
  )

  const lessons = lessonsRequest.data?.lessons || []
  const courseInfo = lessonsRequest.data?.course

  useEffect(() => {
    if (selectedCourse || !courses.length) return
    const fromQuery = searchParams.get('course')
    const match = courses.find((course) => course.id === fromQuery)
    setSelectedCourse(match ? match.id : courses[0].id)
  }, [courses, selectedCourse, searchParams])

  useEffect(() => {
    if (editingId || !lessons.length) return
    const nextOrder = Math.max(...lessons.map((lesson) => lesson.order)) + 1
    setOrder(String(nextOrder))
  }, [lessons, editingId])

  function resetForm(nextOrder) {
    setEditingId('')
    setTitle('')
    setDescription('')
    setDurationMinutes('')
    setIsPreview(false)
    setSelectedFile(null)
    setFileInputKey((key) => key + 1)
    setOrder(String(nextOrder || lessons.length + 1))
  }

  function startEdit(lesson) {
    setEditingId(lesson.id)
    setTitle(lesson.title)
    setDescription(lesson.description || '')
    setOrder(String(lesson.order))
    setDurationMinutes(
      lesson.durationMinutes ? String(lesson.durationMinutes) : ''
    )
    setIsPreview(Boolean(lesson.isPreview))
    setSelectedFile(null)
    setFileInputKey((key) => key + 1)
    setError('')
    setMessage('')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  async function handleSaveLesson(event) {
    event.preventDefault()
    setError('')
    setMessage('')

    if (!selectedCourse) {
      setError('Please create or select a course first.')
      return
    }

    if (title.trim().length < 2) {
      setError('Please enter a lesson title with at least 2 characters.')
      return
    }

    if (!Number.isInteger(Number(order)) || Number(order) < 1) {
      setError('Lesson order must be a whole number of at least 1.')
      return
    }

    if (
      durationMinutes !== '' &&
      (!Number.isFinite(Number(durationMinutes)) ||
        Number(durationMinutes) < 0)
    ) {
      setError('Duration must be zero or a positive number.')
      return
    }

    const formData = new FormData()
    formData.append('title', title.trim())
    formData.append('description', description.trim())
    formData.append('order', order)
    formData.append('isPreview', String(isPreview))
    if (durationMinutes !== '') {
      formData.append('durationMinutes', durationMinutes)
    }
    if (selectedFile) formData.append('video', selectedFile)

    setSaving(true)

    try {
      if (editingId) {
        await lessonApi.update(editingId, formData)
        setMessage(`Lesson "${title.trim()}" was updated.`)
      } else {
        await lessonApi.create(selectedCourse, formData)
        setMessage(
          selectedFile
            ? 'Lesson and video uploaded successfully.'
            : 'Lesson created successfully.'
        )
      }

      resetForm()
      lessonsRequest.reload()
      coursesRequest.reload()
    } catch (err) {
      setError(err.message || 'Upload failed. Please try again.')
    } finally {
      setSaving(false)
    }
  }

  async function removeLesson(lesson) {
    const confirmed = window.confirm(
      `Delete the lesson "${lesson.title}"? Its progress records will also be removed.`
    )
    if (!confirmed) return

    setBusyLessonId(lesson.id)
    setError('')
    setMessage('')
    try {
      await lessonApi.remove(lesson.id)
      setMessage(`Lesson "${lesson.title}" was deleted.`)
      if (editingId === lesson.id) resetForm()
      lessonsRequest.reload()
      coursesRequest.reload()
    } catch (err) {
      setError(err.message)
    } finally {
      setBusyLessonId('')
    }
  }

  function handleCourseChange(event) {
    setSelectedCourse(event.target.value)
    setEditingId('')
    setTitle('')
    setDescription('')
    setDurationMinutes('')
    setIsPreview(false)
    setSelectedFile(null)
    setOrder('1')
    setError('')
    setMessage('')
  }

  if (coursesRequest.loading) {
    return <LoadingState message="Loading your courses..." />
  }
  if (coursesRequest.error) {
    return (
      <ErrorState
        message={coursesRequest.error}
        onRetry={coursesRequest.reload}
      />
    )
  }

  return (
    <>
      <PageHeading
        eyebrow="BRING YOUR COURSE TO LIFE"
        title="Lessons & videos"
        description="Organize your lessons and upload video content."
        action={
          <Link to="/instructor/courses" className="text-link">
            Back to courses <ArrowRight size={16} />
          </Link>
        }
      />

      {message && (
        <p className="success-message" role="status">
          {message}
        </p>
      )}
      {error && (
        <p className="error-message" role="alert">
          {error}
        </p>
      )}

      {!courses.length ? (
        <EmptyState
          title="Create a course first"
          description="Lessons belong to a course, so start by creating one."
          action={
            <Link
              to="/instructor/create-course"
              className="button button-primary button-small"
            >
              Create a course <ArrowRight size={16} />
            </Link>
          }
        />
      ) : (
        <div className="two-column-panels lessons-panels">
          <form className="form-panel" onSubmit={handleSaveLesson}>
            <div className="panel-title-row">
              <h2>{editingId ? 'Edit lesson' : 'Add a lesson'}</h2>
              {editingId && (
                <button
                  type="button"
                  className="link-button"
                  onClick={() => resetForm()}
                >
                  Cancel edit
                </button>
              )}
            </div>

            <label>
              Choose course
              <select
                required
                value={selectedCourse}
                onChange={handleCourseChange}
                disabled={saving}
              >
                {courses.map((course) => (
                  <option key={course.id} value={course.id}>
                    {course.title}
                  </option>
                ))}
              </select>
            </label>

            <label>
              Lesson title
              <input
                required
                minLength={2}
                maxLength={140}
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                placeholder="e.g. Getting started"
                disabled={saving}
              />
            </label>

            <label>
              Lesson description
              <textarea
                rows={3}
                maxLength={3000}
                value={description}
                onChange={(event) => setDescription(event.target.value)}
                placeholder="What will students learn in this lesson?"
                disabled={saving}
              />
            </label>

            <div className="field-row">
              <label>
                Lesson order
                <input
                  type="number"
                  min={1}
                  step={1}
                  required
                  value={order}
                  onChange={(event) => setOrder(event.target.value)}
                  disabled={saving}
                />
              </label>

              <label>
                Duration in minutes
                <input
                  type="number"
                  min={0}
                  step={1}
                  value={durationMinutes}
                  onChange={(event) => setDurationMinutes(event.target.value)}
                  placeholder="e.g. 12"
                  disabled={saving}
                />
              </label>
            </div>

            <label>
              Video file (optional)
              <div className="upload-placeholder">
                <UploadCloud size={24} />
                <strong>
                  {selectedFile ? selectedFile.name : 'Choose a video file'}
                </strong>
                <span>
                  MP4, WebM, MOV or MKV
                  {editingId
                    ? ' — leave empty to keep the current video'
                    : ''}
                </span>
                <input
                  key={fileInputKey}
                  type="file"
                  accept=".mp4,.webm,.mov,.mkv,video/mp4,video/webm,video/quicktime,video/x-matroska"
                  onChange={(event) =>
                    setSelectedFile(event.target.files?.[0] || null)
                  }
                  disabled={saving}
                />
              </div>
            </label>

            <label className="check-row">
              <input
                type="checkbox"
                checked={isPreview}
                onChange={(event) => setIsPreview(event.target.checked)}
                disabled={saving}
              />
              <span>
                <strong>Free preview lesson</strong>
                <small>
                  Allow students to watch this lesson without enrolling.
                </small>
              </span>
            </label>

            <button
              className="button button-primary"
              type="submit"
              disabled={saving}
            >
              {saving
                ? 'Saving lesson...'
                : editingId
                  ? 'Update lesson'
                  : 'Save lesson'}
              {!saving && <ArrowRight size={17} />}
            </button>
          </form>

          <section className="form-panel">
            <div className="panel-title-row">
              <h2>Course lessons</h2>
              <button
                type="button"
                className="icon-button"
                title="Refresh lessons"
                aria-label="Refresh lessons"
                onClick={lessonsRequest.reload}
              >
                <RefreshCw size={17} />
              </button>
            </div>

            {courseInfo && (
              <p className="muted small">
                {courseInfo.title} · {lessons.length} lesson
                {lessons.length === 1 ? '' : 's'} · {courseInfo.studentCount}{' '}
                student{courseInfo.studentCount === 1 ? '' : 's'}
              </p>
            )}

            {lessonsRequest.loading ? (
              <LoadingState message="Loading lessons..." />
            ) : lessonsRequest.error ? (
              <ErrorState
                message={lessonsRequest.error}
                onRetry={lessonsRequest.reload}
              />
            ) : lessons.length ? (
              <div className="admin-list">
                {lessons.map((lesson) => (
                  <div className="admin-row" key={lesson.id}>
                    <span className="lesson-number">{lesson.order}</span>
                    <div className="admin-row-info">
                      <strong>{lesson.title}</strong>
                      <span>
                        {formatMinutes(lesson.durationMinutes)}
                        {lesson.hasVideo ? ' · Video' : ' · No video'}
                        {lesson.isPreview ? ' · Preview' : ''}
                      </span>
                    </div>
                    <div className="row-actions">
                      <button
                        type="button"
                        className="icon-button"
                        title="Edit lesson"
                        aria-label={`Edit ${lesson.title}`}
                        onClick={() => startEdit(lesson)}
                      >
                        <Pencil size={16} />
                      </button>
                      <button
                        type="button"
                        className="icon-button danger"
                        title="Delete lesson"
                        aria-label={`Delete ${lesson.title}`}
                        disabled={busyLessonId === lesson.id}
                        onClick={() => removeLesson(lesson)}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState
                title="No lessons yet"
                description="Use the form to add the first lesson to this course."
              />
            )}
          </section>
        </div>
      )}
    </>
  )
}

function blankQuestion() {
  return {
    prompt: '',
    options: ['', '', '', ''],
    correctOptionIndex: 0,
    points: 1
  }
}

export function ManageQuizzes() {
  const [searchParams] = useSearchParams()
  const coursesRequest = useApi(courseApi.mine, [])
  const courses = coursesRequest.data?.courses || []

  const [selectedCourse, setSelectedCourse] = useState('')
  const [editingId, setEditingId] = useState('')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [passingScore, setPassingScore] = useState('60')
  const [timeLimitMinutes, setTimeLimitMinutes] = useState('0')
  const [questions, setQuestions] = useState([blankQuestion()])
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const [busyId, setBusyId] = useState('')

  const quizzesRequest = useApi(quizApi.mine, [])

  useEffect(() => {
    if (selectedCourse || !courses.length) return
    const fromQuery = searchParams.get('course')
    const match = courses.find((course) => course.id === fromQuery)
    setSelectedCourse(match ? match.id : courses[0].id)
  }, [courses, selectedCourse, searchParams])

  const quizzes = useMemo(
    () =>
      (quizzesRequest.data?.quizzes || []).filter(
        (quiz) => quiz.courseId === selectedCourse
      ),
    [quizzesRequest.data, selectedCourse]
  )

  function resetForm() {
    setEditingId('')
    setTitle('')
    setDescription('')
    setPassingScore('60')
    setTimeLimitMinutes('0')
    setQuestions([blankQuestion()])
    setError('')
  }

  function startEdit(quiz) {
    setEditingId(quiz.id)
    setTitle(quiz.title)
    setDescription(quiz.description || '')
    setPassingScore(String(quiz.passingScore ?? 60))
    setTimeLimitMinutes(String(quiz.timeLimitMinutes ?? 0))
    setQuestions(
      quiz.questions.map((question) => ({
        prompt: question.prompt,
        options: [...question.options],
        correctOptionIndex: question.correctOptionIndex ?? 0,
        points: question.points || 1
      }))
    )
    setError('')
    setMessage('')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function updateQuestion(index, changes) {
    setQuestions((current) =>
      current.map((question, questionIndex) =>
        questionIndex === index ? { ...question, ...changes } : question
      )
    )
  }

  function updateOption(questionIndex, optionIndex, value) {
    setQuestions((current) =>
      current.map((question, index) =>
        index === questionIndex
          ? {
              ...question,
              options: question.options.map((option, currentIndex) =>
                currentIndex === optionIndex ? value : option
              )
            }
          : question
      )
    )
  }

  function addOption(questionIndex) {
    setQuestions((current) =>
      current.map((question, index) =>
        index === questionIndex && question.options.length < 6
          ? { ...question, options: [...question.options, ''] }
          : question
      )
    )
  }

  function removeOption(questionIndex) {
    setQuestions((current) =>
      current.map((question, index) => {
        if (index !== questionIndex || question.options.length <= 2) {
          return question
        }
        const options = question.options.slice(0, -1)
        return {
          ...question,
          options,
          correctOptionIndex: Math.min(
            question.correctOptionIndex,
            options.length - 1
          )
        }
      })
    )
  }

  async function handleSaveQuiz(event) {
    event.preventDefault()
    setError('')
    setMessage('')

    if (!selectedCourse) {
      setError('Choose a course for this quiz.')
      return
    }

    if (title.trim().length < 2) {
      setError('Quiz title must contain at least 2 characters.')
      return
    }

    const prepared = []

    for (const [index, question] of questions.entries()) {
      if (question.prompt.trim().length < 3) {
        setError(`Question ${index + 1} needs a prompt.`)
        return
      }

      const filledOptions = question.options
        .map((option, optionIndex) => ({
          text: option.trim(),
          originalIndex: optionIndex
        }))
        .filter((option) => option.text.length > 0)

      if (filledOptions.length < 2) {
        setError(`Question ${index + 1} needs at least two answer options.`)
        return
      }

      const correctOption = filledOptions.find(
        (option) => option.originalIndex === question.correctOptionIndex
      )

      if (!correctOption) {
        setError(
          `Question ${index + 1}: the correct answer must be one of the filled options.`
        )
        return
      }

      prepared.push({
        prompt: question.prompt.trim(),
        options: filledOptions.map((option) => option.text),
        correctOptionIndex: filledOptions.indexOf(correctOption),
        points: 1
      })
    }

    const payload = {
      title: title.trim(),
      description: description.trim(),
      passingScore: Number(passingScore),
      timeLimitMinutes: Number(timeLimitMinutes),
      questions: prepared
    }

    if (
      !Number.isFinite(payload.passingScore) ||
      payload.passingScore < 0 ||
      payload.passingScore > 100
    ) {
      setError('Passing score must be between 0 and 100.')
      return
    }

    if (
      !Number.isFinite(payload.timeLimitMinutes) ||
      payload.timeLimitMinutes < 0 ||
      payload.timeLimitMinutes > 300
    ) {
      setError('Time limit must be between 0 and 300 minutes.')
      return
    }

    setSaving(true)

    try {
      if (editingId) {
        await quizApi.update(editingId, payload)
        setMessage(`Quiz "${payload.title}" was updated.`)
      } else {
        await quizApi.create(selectedCourse, payload)
        setMessage(`Quiz "${payload.title}" was created.`)
      }
      resetForm()
      quizzesRequest.reload()
    } catch (err) {
      setError(err.message)
    } finally {
      setSaving(false)
    }
  }

  async function removeQuiz(quiz) {
    const confirmed = window.confirm(
      `Delete the quiz "${quiz.title}"? All student attempts for it will also be deleted.`
    )
    if (!confirmed) return

    setBusyId(quiz.id)
    setError('')
    setMessage('')
    try {
      await quizApi.remove(quiz.id)
      setMessage(`Quiz "${quiz.title}" was deleted.`)
      quizzesRequest.reload()
      if (editingId === quiz.id) resetForm()
    } catch (err) {
      setError(err.message)
    } finally {
      setBusyId('')
    }
  }

  function handleCourseChange(event) {
    setSelectedCourse(event.target.value)
    resetForm()
    setMessage('')
  }

  if (coursesRequest.loading) {
    return <LoadingState message="Loading your courses..." />
  }
  if (coursesRequest.error) {
    return (
      <ErrorState
        message={coursesRequest.error}
        onRetry={coursesRequest.reload}
      />
    )
  }

  return (
    <>
      <PageHeading
        eyebrow="CHECK UNDERSTANDING"
        title="Quiz management"
        description="Build knowledge checks that are scored securely by the server."
        action={
          <Link to="/instructor/courses" className="text-link">
            Back to courses <ArrowRight size={16} />
          </Link>
        }
      />

      {message && (
        <p className="success-message" role="status">
          {message}
        </p>
      )}
      {error && (
        <p className="error-message" role="alert">
          {error}
        </p>
      )}

      {!courses.length ? (
        <EmptyState
          title="Create a course first"
          description="Quizzes belong to a course, so start by creating one."
          action={
            <Link
              to="/instructor/create-course"
              className="button button-primary button-small"
            >
              Create a course <ArrowRight size={16} />
            </Link>
          }
        />
      ) : (
        <>
          <section className="form-panel">
            <label>
              Choose course
              <select
                value={selectedCourse}
                onChange={handleCourseChange}
                disabled={saving}
              >
                {courses.map((course) => (
                  <option key={course.id} value={course.id}>
                    {course.title}
                  </option>
                ))}
              </select>
            </label>

            <div className="panel-title-row">
              <h2>Quizzes in this course</h2>
              <button
                type="button"
                className="icon-button"
                title="Refresh quizzes"
                aria-label="Refresh quizzes"
                onClick={quizzesRequest.reload}
              >
                <RefreshCw size={17} />
              </button>
            </div>

            {quizzesRequest.loading ? (
              <LoadingState message="Loading quizzes..." />
            ) : quizzesRequest.error ? (
              <ErrorState
                message={quizzesRequest.error}
                onRetry={quizzesRequest.reload}
              />
            ) : quizzes.length ? (
              <div className="admin-list">
                {quizzes.map((quiz) => (
                  <div className="admin-row" key={quiz.id}>
                    <span className="quiz-card-icon">
                      <FileQuestion size={18} />
                    </span>
                    <div className="admin-row-info">
                      <strong>{quiz.title}</strong>
                      <span>
                        {quiz.questionCount} question
                        {quiz.questionCount === 1 ? '' : 's'} · Pass at{' '}
                        {quiz.passingScore}% · {quiz.attemptsCount} attempt
                        {quiz.attemptsCount === 1 ? '' : 's'}
                      </span>
                    </div>
                    <div className="row-actions">
                      <button
                        type="button"
                        className="icon-button"
                        title="Edit quiz"
                        aria-label={`Edit ${quiz.title}`}
                        onClick={() => startEdit(quiz)}
                      >
                        <Pencil size={16} />
                      </button>
                      <button
                        type="button"
                        className="icon-button danger"
                        title="Delete quiz"
                        aria-label={`Delete ${quiz.title}`}
                        disabled={busyId === quiz.id}
                        onClick={() => removeQuiz(quiz)}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="muted small">
                No quizzes in this course yet. Build one below.
              </p>
            )}
          </section>

          <form className="form-panel quiz-builder" onSubmit={handleSaveQuiz}>
            <div className="panel-title-row">
              <h2>{editingId ? 'Edit quiz' : 'Create a quiz'}</h2>
              {editingId && (
                <button type="button" className="link-button" onClick={resetForm}>
                  Cancel edit
                </button>
              )}
            </div>

            <label>
              Quiz title
              <input
                required
                minLength={2}
                maxLength={140}
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                placeholder="e.g. React basics"
                disabled={saving}
              />
            </label>

            <label>
              Description (optional)
              <textarea
                rows={2}
                maxLength={2000}
                value={description}
                onChange={(event) => setDescription(event.target.value)}
                placeholder="What is this quiz checking?"
                disabled={saving}
              />
            </label>

            <div className="field-row">
              <label>
                Passing score (%)
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={passingScore}
                  onChange={(event) => setPassingScore(event.target.value)}
                  disabled={saving}
                />
              </label>
              <label>
                Time limit (minutes, 0 = none)
                <input
                  type="number"
                  min={0}
                  max={300}
                  value={timeLimitMinutes}
                  onChange={(event) => setTimeLimitMinutes(event.target.value)}
                  disabled={saving}
                />
              </label>
            </div>

            {questions.map((question, questionIndex) => (
              <div className="question-editor" key={questionIndex}>
                <div className="panel-title-row">
                  <strong>Question {questionIndex + 1}</strong>
                  {questions.length > 1 && (
                    <button
                      type="button"
                      className="icon-button danger"
                      title="Remove question"
                      aria-label={`Remove question ${questionIndex + 1}`}
                      onClick={() =>
                        setQuestions((current) =>
                          current.filter((_, index) => index !== questionIndex)
                        )
                      }
                    >
                      <X size={16} />
                    </button>
                  )}
                </div>

                <label>
                  Prompt
                  <input
                    value={question.prompt}
                    onChange={(event) =>
                      updateQuestion(questionIndex, {
                        prompt: event.target.value
                      })
                    }
                    placeholder="Type the question"
                    disabled={saving}
                  />
                </label>

                <div className="option-editor-list">
                  {question.options.map((option, optionIndex) => (
                    <label
                      className={`option-editor ${
                        question.correctOptionIndex === optionIndex
                          ? 'selected-correct'
                          : ''
                      }`}
                      key={optionIndex}
                    >
                      <input
                        type="radio"
                        name={`correct-${questionIndex}`}
                        checked={question.correctOptionIndex === optionIndex}
                        onChange={() =>
                          updateQuestion(questionIndex, {
                            correctOptionIndex: optionIndex
                          })
                        }
                        disabled={saving}
                        title="Mark as the correct answer"
                      />
                      <span>{String.fromCharCode(65 + optionIndex)}</span>
                      <input
                        type="text"
                        value={option}
                        onChange={(event) =>
                          updateOption(
                            questionIndex,
                            optionIndex,
                            event.target.value
                          )
                        }
                        placeholder={`Option ${optionIndex + 1}`}
                        disabled={saving}
                      />
                    </label>
                  ))}
                </div>

                <div className="editor-actions">
                  <button
                    type="button"
                    className="link-button"
                    onClick={() => addOption(questionIndex)}
                    disabled={saving || question.options.length >= 6}
                  >
                    + Add option
                  </button>
                  <button
                    type="button"
                    className="link-button"
                    onClick={() => removeOption(questionIndex)}
                    disabled={saving || question.options.length <= 2}
                  >
                    Remove last option
                  </button>
                  <span className="muted small">
                    Select the radio button next to the correct answer.
                  </span>
                </div>
              </div>
            ))}

            <div className="editor-actions">
              <button
                type="button"
                className="button button-outline button-small"
                onClick={() =>
                  setQuestions((current) => [...current, blankQuestion()])
                }
                disabled={saving || questions.length >= 100}
              >
                <Plus size={15} /> Add question
              </button>
            </div>

            <div className="form-actions">
              <button
                type="submit"
                className="button button-primary"
                disabled={saving}
              >
                {saving
                  ? 'Saving quiz...'
                  : editingId
                    ? 'Update quiz'
                    : 'Create quiz'}
                {!saving && <ArrowRight size={17} />}
              </button>
            </div>
          </form>
        </>
      )}
    </>
  )
}

function escapeCsv(value) {
  const text = String(value ?? '')
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text
}

function downloadCsv(filename, rows) {
  const csv = rows.map((row) => row.map(escapeCsv).join(',')).join('\r\n')
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  link.remove()
  URL.revokeObjectURL(url)
}

export function InstructorStudents() {
  const { data, loading, error, reload } = useApi(instructorApi.students, [])
  const [search, setSearch] = useState('')

  const students = data?.students || []
  const results = data?.quizResults || []

  const filteredStudents = useMemo(() => {
    const term = search.trim().toLowerCase()
    if (!term) return students
    return students.filter((student) =>
      `${student.name} ${student.email} ${student.courseTitle}`
        .toLowerCase()
        .includes(term)
    )
  }, [students, search])

  if (loading) return <LoadingState message="Loading your students..." />
  if (error) return <ErrorState message={error} onRetry={reload} />

  function exportStudents() {
    downloadCsv('learning-hub-students.csv', [
      [
        'Student',
        'Email',
        'Course',
        'Progress %',
        'Completed lessons',
        'Total lessons',
        'Status',
        'Enrolled at'
      ],
      ...students.map((student) => [
        student.name,
        student.email,
        student.courseTitle,
        student.progressPercent,
        student.completedLessons,
        student.totalLessons,
        student.status,
        formatDate(student.enrolledAt)
      ])
    ])
  }

  function exportResults() {
    downloadCsv('learning-hub-quiz-results.csv', [
      [
        'Student',
        'Email',
        'Course',
        'Quiz',
        'Score',
        'Total points',
        'Percentage',
        'Passed',
        'Submitted at'
      ],
      ...results.map((result) => [
        result.studentName,
        result.studentEmail,
        result.courseTitle,
        result.quizTitle,
        result.score,
        result.totalPoints,
        result.percentage,
        result.passed ? 'Yes' : 'No',
        formatDateTime(result.submittedAt)
      ])
    ])
  }

  return (
    <>
      <PageHeading
        eyebrow="YOUR LEARNING COMMUNITY"
        title="Students & results"
        description="A live snapshot of the learners in your courses."
        action={
          <div className="row-actions">
            <button
              type="button"
              className="button button-outline"
              onClick={exportStudents}
              disabled={!students.length}
            >
              <Download size={17} /> Export students
            </button>
            <button
              type="button"
              className="button button-primary"
              onClick={exportResults}
              disabled={!results.length}
            >
              <Download size={17} /> Export results
            </button>
          </div>
        }
      />

      <div className="toolbar">
        <label className="search-box">
          <Search size={17} />
          <input
            type="search"
            placeholder="Search by student, email or course..."
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </label>
        <span className="muted small">
          {filteredStudents.length} enrollment
          {filteredStudents.length === 1 ? '' : 's'}
        </span>
      </div>

      <div className="table-panel">
        <div className="table-head">
          <h2>Enrolled students</h2>
          <span className="muted small">
            {students.length} total enrollment{students.length === 1 ? '' : 's'}
          </span>
        </div>

        {filteredStudents.length ? (
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>Student</th>
                  <th>Course</th>
                  <th>Progress</th>
                  <th>Status</th>
                  <th>Enrolled</th>
                </tr>
              </thead>
              <tbody>
                {filteredStudents.map((student) => (
                  <tr key={student.enrollmentId}>
                    <td>
                      <strong>{student.name}</strong>
                      <small>{student.email}</small>
                    </td>
                    <td>{student.courseTitle}</td>
                    <td>
                      <div className="table-progress">
                        <ProgressBar value={student.progressPercent} />
                        <span>{student.progressPercent}%</span>
                      </div>
                    </td>
                    <td>
                      <span
                        className={`status-pill ${
                          student.status === 'completed' ? 'pass' : 'neutral'
                        }`}
                      >
                        {student.status}
                      </span>
                    </td>
                    <td>{formatDate(student.enrolledAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            title="No enrollments yet"
            description="Once a student enrolls in one of your courses, they will appear here."
          />
        )}
      </div>

      <div className="section-row section-row-spaced">
        <div>
          <h2>Quiz results</h2>
          <p className="muted">Every submitted attempt, scored by the server.</p>
        </div>
      </div>

      <div className="table-panel">
        {results.length ? (
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>Student</th>
                  <th>Quiz</th>
                  <th>Score</th>
                  <th>Result</th>
                  <th>Submitted</th>
                </tr>
              </thead>
              <tbody>
                {results.map((result) => (
                  <tr key={result.attemptId}>
                    <td>
                      <strong>{result.studentName}</strong>
                      <small>{result.studentEmail}</small>
                    </td>
                    <td>
                      <strong>{result.quizTitle}</strong>
                      <small>{result.courseTitle}</small>
                    </td>
                    <td>
                      {result.score}/{result.totalPoints} ({result.percentage}%)
                    </td>
                    <td>
                      <span
                        className={`status-pill ${
                          result.passed ? 'pass' : 'fail'
                        }`}
                      >
                        {result.passed ? 'Passed' : 'Not passed'}
                      </span>
                    </td>
                    <td>{formatDateTime(result.submittedAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            title="No quiz attempts yet"
            description="Student quiz results will appear here after they submit a quiz."
          />
        )}
      </div>
    </>
  )
}
