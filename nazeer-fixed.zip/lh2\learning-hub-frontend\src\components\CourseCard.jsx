import { ArrowUpRight, Clock3, PlayCircle } from 'lucide-react'
import { Link } from 'react-router-dom'
import ProgressBar from './ProgressBar'
import { clampPercent, courseColor, courseEmoji } from '../utils/ui'

export default function CourseCard({ course, showProgress = true }) {
  const courseId = course?.id || course?._id
  const progress = clampPercent(
    course?.progressPercent ?? course?.progress ?? 0
  )

  const instructor =
    course?.instructorName ||
    course?.instructor?.name ||
    'Learning Hub instructor'

  const duration = course?.totalLessons
    ? `${course.totalLessons} lesson${course.totalLessons === 1 ? '' : 's'}`
    : course?.lessonCount
      ? `${course.lessonCount} lesson${course.lessonCount === 1 ? '' : 's'}`
      : 'Self-paced'

  const category = course?.category || 'General'
  const level = course?.level || 'Beginner'
  const title = course?.title || 'Untitled course'
  const color = courseColor(courseId || title)

  return (
    <article className="course-card">
      <div
        className={`course-art ${color}`}
        style={
          course?.thumbnail
            ? {
                backgroundImage: `url(${course.thumbnail})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }
            : undefined
        }
      >
        {!course?.thumbnail && (
          <span className="course-emoji">{courseEmoji(category)}</span>
        )}

        <span className="course-category">{category}</span>
        <span className="art-orbit orbit-one" />
        <span className="art-orbit orbit-two" />
      </div>

      <div className="course-card-body">
        <div className="course-meta">
          <span>{level}</span>
          <span>
            <Clock3 size={14} />
            {duration}
          </span>
        </div>

        <h3>{title}</h3>
        <p className="muted small">By {instructor}</p>

        {showProgress && (
          <div className="course-progress">
            <div className="progress-label">
              <span>Your progress</span>
              <strong>{progress}%</strong>
            </div>
            <ProgressBar value={progress} />
          </div>
        )}

        {courseId ? (
          <Link className="card-link" to={`/student/course/${courseId}`}>
            {progress === 100
              ? 'Review course'
              : progress > 0
                ? 'Continue learning'
                : 'View course'}
            {progress > 0 ? (
              <PlayCircle size={17} />
            ) : (
              <ArrowUpRight size={17} />
            )}
          </Link>
        ) : (
          <span className="card-link" aria-disabled="true">
            Course details unavailable
          </span>
        )}
      </div>
    </article>
  )
}
