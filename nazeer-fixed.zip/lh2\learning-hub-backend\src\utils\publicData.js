function idOf(value) {
  return value ? String(value._id || value) : null
}

exports.publicUser = (user) => ({
  id: idOf(user),
  name: user.name,
  email: user.email,
  role: user.role,
  avatar: user.avatar || ''
})

exports.publicLesson = (lesson, options = {}) => {
  const { includeVideo = false, locked = false } = options
  const hasVideo = Boolean(lesson.videoPath || lesson.videoUrl)

  return {
    id: idOf(lesson),
    courseId: idOf(lesson.course),
    title: lesson.title,
    description: lesson.description || '',
    order: lesson.order,
    durationMinutes: lesson.durationMinutes || 0,
    isPreview: Boolean(lesson.isPreview),
    hasVideo,
    videoUrl: locked ? '' : lesson.videoUrl || '',
    ...(includeVideo && hasVideo && !locked
      ? { videoStreamUrl: `/api/lessons/${idOf(lesson)}/video` }
      : {}),
    videoOriginalName: lesson.videoOriginalName || '',
    videoSize: lesson.videoSize || 0
  }
}

exports.publicQuiz = (quiz, options = {}) => {
  const { includeAnswers = false } = options

  return {
    id: idOf(quiz),
    courseId: idOf(quiz.course),
    lessonId: quiz.lesson ? idOf(quiz.lesson) : null,
    title: quiz.title,
    description: quiz.description || '',
    timeLimitMinutes: quiz.timeLimitMinutes || 0,
    passingScore: quiz.passingScore ?? 60,
    questionCount: Array.isArray(quiz.questions) ? quiz.questions.length : 0,
    questions: (quiz.questions || []).map((question) => ({
      id: idOf(question),
      prompt: question.prompt,
      options: question.options,
      points: question.points || 1,
      ...(includeAnswers
        ? { correctOptionIndex: question.correctOptionIndex }
        : {})
    }))
  }
}
