import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState
} from 'react'
import {
  authApi,
  clearAuthToken,
  getAuthToken,
  setAuthToken
} from '../services/api'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [authLoading, setAuthLoading] = useState(true)

  useEffect(() => {
    let active = true

    async function restoreSession() {
      if (!getAuthToken()) {
        if (active) setAuthLoading(false)
        return
      }

      try {
        const data = await authApi.me()
        if (active) setUser(data.user || null)
      } catch {
        clearAuthToken()
        if (active) setUser(null)
      } finally {
        if (active) setAuthLoading(false)
      }
    }

    restoreSession()

    return () => {
      active = false
    }
  }, [])

  const value = useMemo(
    () => ({
      user,
      authLoading,

      async registerStudent({ name, email, password }) {
        try {
          const data = await authApi.register({ name, email, password })
          setAuthToken(data.token)
          setUser(data.user)
          return { success: true, user: data.user }
        } catch (error) {
          return { success: false, message: error.message }
        }
      },

      async login({ email, password, role }) {
        try {
          const data = await authApi.login({ email, password, role })
          setAuthToken(data.token)
          setUser(data.user)
          return { success: true, user: data.user }
        } catch (error) {
          return { success: false, message: error.message }
        }
      },

      logout() {
        clearAuthToken()
        setUser(null)
      }
    }),
    [user, authLoading]
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)

  if (!context) {
    throw new Error('useAuth must be used inside AuthProvider')
  }

  return context
}
