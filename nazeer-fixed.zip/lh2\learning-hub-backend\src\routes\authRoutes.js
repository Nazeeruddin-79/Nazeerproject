const router = require('express').Router()
const rateLimit = require('express-rate-limit')
const controller = require('../controllers/authController')
const { protect } = require('../middleware/auth')
const validate = require('../middleware/validate')
const asyncHandler = require('../utils/asyncHandler')

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many sign-in attempts. Try again later.'
  }
})

router.post(
  '/register',
  limiter,
  validate(controller.registerSchema),
  asyncHandler(controller.register)
)

router.post(
  '/login',
  limiter,
  validate(controller.loginSchema),
  asyncHandler(controller.login)
)

router.get('/me', protect, asyncHandler(controller.me))

module.exports = router
