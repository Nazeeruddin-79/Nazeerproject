const router = require('express').Router()
const { protect, allowRoles } = require('../middleware/auth')
const controller = require('../controllers/studentController')
const asyncHandler = require('../utils/asyncHandler')

router.use(protect, allowRoles('student'))

router.get('/dashboard', asyncHandler(controller.dashboard))
router.get('/courses', asyncHandler(controller.courses))
router.get('/courses/:courseId/lessons', asyncHandler(controller.lessons))
router.get('/progress', asyncHandler(controller.progress))
router.get('/quizzes', asyncHandler(controller.quizzes))

module.exports = router
