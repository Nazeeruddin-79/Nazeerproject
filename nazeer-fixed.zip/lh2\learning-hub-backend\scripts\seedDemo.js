/**
 * Creates a ready-to-use demo dataset:
 *   - one instructor and one student account
 *   - three published courses with lessons and quizzes
 *   - two enrollments for the demo student
 *
 * Run with: npm run seed
 * Safe to run more than once: existing accounts/courses are reused.
 */
require('../src/config/env')

const mongoose = require('mongoose')
const User = require('../src/models/User')
const Course = require('../src/models/Course')
const Lesson = require('../src/models/Lesson')
const Enrollment = require('../src/models/Enrollment')
const Quiz = require('../src/models/Quiz')

const DEMO_VIDEO =
  'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4'

const INSTRUCTOR = {
  name: 'Maya Chen',
  email: 'instructor@learnhub.dev',
  password: 'TeachPass123!'
}

const STUDENT = {
  name: 'Jamie Parker',
  email: 'student@learnhub.dev',
  password: 'LearnPass123!'
}

const COURSES = [
  {
    title: 'React Foundations',
    description:
      'Build a strong foundation in modern React: components, props, state and the patterns used to create real-world interfaces.',
    category: 'Development',
    level: 'Beginner',
    lessons: [
      {
        title: 'Welcome to the course',
        description: 'What you will build and how to get the most from this course.',
        durationMinutes: 5,
        isPreview: true
      },
      {
        title: 'How React thinks',
        description: 'Components, the virtual DOM and why React is different.',
        durationMinutes: 12
      },
      {
        title: 'Your first component',
        description: 'Create and compose your first reusable component.',
        durationMinutes: 16
      },
      {
        title: 'Props and reusable UI',
        description: 'Pass data into components and keep your UI reusable.',
        durationMinutes: 18
      }
    ],
    quiz: {
      title: 'React basics',
      description: 'A short knowledge check for the React Foundations course.',
      passingScore: 60,
      timeLimitMinutes: 10,
      questions: [
        {
          prompt: 'What is a React component?',
          options: [
            'A reusable piece of UI',
            'A database',
            'A CSS property',
            'A web browser'
          ],
          correctOptionIndex: 0
        },
        {
          prompt: 'Which hook is commonly used to manage local component state?',
          options: ['useRoute', 'useState', 'useStyle', 'useServer'],
          correctOptionIndex: 1
        },
        {
          prompt: 'What does JSX allow you to write?',
          options: [
            'SQL inside CSS',
            'HTML-like syntax in JavaScript',
            'Only JSON',
            'Server configuration'
          ],
          correctOptionIndex: 1
        }
      ]
    }
  },
  {
    title: 'UI Design Essentials',
    description:
      'Learn visual hierarchy, spacing, colour, typography and how to turn ideas into clear digital experiences.',
    category: 'Design',
    level: 'Beginner',
    lessons: [
      {
        title: 'Design is communication',
        description: 'The purpose of every screen you design.',
        durationMinutes: 7,
        isPreview: true
      },
      {
        title: 'Spacing and visual rhythm',
        description: 'Use spacing to create calm, readable layouts.',
        durationMinutes: 14
      },
      {
        title: 'Typography that guides the eye',
        description: 'Choose sizes, weights and line lengths that work.',
        durationMinutes: 17
      }
    ],
    quiz: {
      title: 'Design essentials check',
      description: 'Test the core ideas from UI Design Essentials.',
      passingScore: 60,
      timeLimitMinutes: 8,
      questions: [
        {
          prompt: 'What creates visual hierarchy on a page?',
          options: [
            'Random colours',
            'Size, weight and spacing',
            'More text',
            'Hidden content'
          ],
          correctOptionIndex: 1
        },
        {
          prompt: 'Why is whitespace important?',
          options: [
            'It makes pages longer',
            'It improves readability and focus',
            'It hides mistakes',
            'It replaces colour'
          ],
          correctOptionIndex: 1
        }
      ]
    }
  },
  {
    title: 'JavaScript From Zero',
    description:
      'Understand the language of the web, from variables and functions to arrays, objects and asynchronous code.',
    category: 'Development',
    level: 'Beginner',
    lessons: [
      {
        title: 'Variables and values',
        description: 'let, const and the values you will work with every day.',
        durationMinutes: 10,
        isPreview: true
      },
      {
        title: 'Functions and scope',
        description: 'Write reusable logic and understand where variables live.',
        durationMinutes: 15
      },
      {
        title: 'Arrays and objects',
        description: 'Store and transform groups of related data.',
        durationMinutes: 19
      }
    ],
    quiz: {
      title: 'JavaScript fundamentals',
      description: 'Check your understanding of JavaScript basics.',
      passingScore: 70,
      timeLimitMinutes: 12,
      questions: [
        {
          prompt: 'Which keyword declares a block-scoped variable?',
          options: ['var', 'let', 'print', 'echo'],
          correctOptionIndex: 1
        },
        {
          prompt: 'What does an array store?',
          options: [
            'A single number only',
            'An ordered list of values',
            'A CSS file',
            'A database connection'
          ],
          correctOptionIndex: 1
        },
        {
          prompt: 'What is a function?',
          options: [
            'A reusable block of code',
            'A type of button',
            'A database table',
            'A browser'
          ],
          correctOptionIndex: 0
        }
      ]
    }
  }
]

async function upsertUser(data) {
  const existing = await User.findOne({ email: data.email })
  if (existing) return existing
  return User.create(data)
}

async function upsertCourse(instructor, data) {
  let course = await Course.findOne({
    instructor: instructor._id,
    title: data.title
  })

  if (!course) {
    course = await Course.create({
      instructor: instructor._id,
      title: data.title,
      description: data.description,
      category: data.category,
      level: data.level,
      status: 'published'
    })
    console.log(`Created course: ${course.title}`)
  } else if (course.status !== 'published') {
    course.status = 'published'
    await course.save()
  }

  for (const [index, lesson] of data.lessons.entries()) {
    const order = index + 1
    const exists = await Lesson.exists({ course: course._id, order })
    if (!exists) {
      await Lesson.create({
        course: course._id,
        title: lesson.title,
        description: lesson.description,
        order,
        durationMinutes: lesson.durationMinutes,
        isPreview: Boolean(lesson.isPreview),
        videoUrl: DEMO_VIDEO
      })
    }
  }

  const quizExists = await Quiz.exists({
    course: course._id,
    title: data.quiz.title
  })

  if (!quizExists) {
    await Quiz.create({
      course: course._id,
      title: data.quiz.title,
      description: data.quiz.description,
      passingScore: data.quiz.passingScore,
      timeLimitMinutes: data.quiz.timeLimitMinutes,
      questions: data.quiz.questions.map((question) => ({
        ...question,
        points: 1
      }))
    })
  }

  return course
}

async function main() {
  await mongoose.connect(process.env.MONGODB_URI)

  const instructor = await upsertUser({ ...INSTRUCTOR, role: 'instructor' })
  const student = await upsertUser({ ...STUDENT, role: 'student' })

  const createdCourses = []
  for (const course of COURSES) {
    createdCourses.push(await upsertCourse(instructor, course))
  }

  for (const course of createdCourses.slice(0, 2)) {
    await Enrollment.updateOne(
      { student: student._id, course: course._id },
      {
        $setOnInsert: {
          student: student._id,
          course: course._id,
          status: 'active',
          enrolledAt: new Date()
        }
      },
      { upsert: true }
    )
  }

  console.log('')
  console.log('Demo data is ready.')
  console.log(`Instructor: ${INSTRUCTOR.email} / ${INSTRUCTOR.password}`)
  console.log(`Student:    ${STUDENT.email} / ${STUDENT.password}`)
  console.log('')

  await mongoose.disconnect()
}

main().catch(async (error) => {
  console.error('Seed failed:', error.message)
  try {
    await mongoose.disconnect()
  } catch {
    // ignore
  }
  process.exitCode = 1
})
