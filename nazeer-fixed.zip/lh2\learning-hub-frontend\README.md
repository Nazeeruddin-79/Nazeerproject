# LearnHub — Frontend

A responsive React + Vite learning platform. Students can browse courses, enroll, watch lessons, complete them, take quizzes and track progress. Instructors can create courses, upload lesson videos, build quizzes and review student results.

The frontend talks to the Express API in `../learning-hub-backend`.

## Requirements

- Node.js 18 or newer
- The backend running at `http://localhost:5000` (default)

## Run locally

From the `learning-hub-frontend` folder:

```bash
npm install
npm run dev
```

Open the URL shown by Vite (normally http://localhost:5173).

The frontend defaults to `http://localhost:5000/api` in development, so no `.env` file is required if the backend runs on port 5000.

To use a different API URL, copy `.env.example` to `.env.local` and set:

```
VITE_API_URL=http://localhost:5000/api
```

## Demo accounts

The backend seed script creates these accounts:

| Role | Email | Password |
|---|---|---|
| Student | `student@learnhub.dev` | `LearnPass123!` |
| Instructor | `instructor@learnhub.dev` | `TeachPass123!` |

In local development the login page also has buttons that fill these credentials automatically.

## Features

### Students

- Register and sign in with a real account
- Explore published courses and search the library
- Enroll in courses and view course details
- Watch preview lessons before enrolling
- Stream protected lesson videos with byte-range seeking
- Mark lessons complete and track progress
- Take server-scored quizzes with optional time limits
- Review lesson activity, quiz attempts and scores

### Instructors

- Dashboard with courses, students, lessons and quiz statistics
- Create, publish, unpublish and delete courses
- Add, edit and delete lessons; upload MP4/WebM/MOV/MKV videos
- Mark lessons as free previews
- Build and edit quizzes with a visual question editor
- Review enrolled students, progress and quiz results
- Export students and quiz results as CSV

## Production build

```bash
npm run build
```

Vite writes the production files to `dist/`.

## Deploying to Vercel

1. Import the `learning-hub-frontend` folder as a Vercel project.
2. Add `VITE_API_URL` pointing to your deployed backend, for example `https://your-api.vercel.app/api`.
3. Deploy. `vercel.json` already rewrites all routes to `index.html` so client-side routing works.

## Notes

- Authentication uses a JWT stored in `localStorage`.
- Video URLs include the token as a query parameter because a native `<video>` element cannot send an `Authorization` header.
- Never put secrets in `VITE_*` variables; they are public in the browser bundle.
