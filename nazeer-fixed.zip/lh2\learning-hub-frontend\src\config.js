// Vite exposes VITE_* variables at build time.
// In development the API runs on localhost; in production set VITE_API_URL.
export const API_URL = (
  import.meta.env.VITE_API_URL ||
  (import.meta.env.DEV ? 'http://localhost:5000/api' : '/api')
).replace(/\/+$/, '')

export const TOKEN_KEY = 'lh-auth-token'
