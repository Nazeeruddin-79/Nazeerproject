import { useEffect, useMemo, useRef, useState } from 'react'
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  CalendarDays,
  CheckCircle2,
  ClipboardList,
  Clock3,
  Flame,
  Lock,
  Play,
  Search,
  Sparkles,
  Target,
  Trophy,
  Video
} from 'lucide-react'
import { Link, useParams, useSearchParams } from 'react-router-dom'
import CourseCard from '../components/CourseCard'
import ProgressBar from '../components/ProgressBar'
import { EmptyState, ErrorState, LoadingState } from '../components/States'
import { useAuth } from '../context/AuthContext'
import { useApi } from '../hooks/useApi'
import {
  authorizedVideoUrl,
  courseApi,
  lessonApi,
  quizApi,
  studentApi
} from '../services/api'
import {
  clampPercent,
  courseColor,
  courseEmoji,
  formatDate,
  formatDateTime,
  formatMinutes,
  greeting
} from '../utils/ui'

function PageHeading({ eyebrow, title, description, action }) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        {description && <p className="muted">{description}</p>}
      </div>
      {action}
    </div>
  )
}

export function StudentDashboard() {
  const { user } = useAuth()
  const { data, loading, error, reload } = useApi(studentApi.dashboard, [])
  const dashboard = data?.dashboard
  const firstName = (user?.name || 'there').split(' ')[0]

  if (loading) return <LoadingState message="Loading your dashboard..." />
  if (error) return <ErrorState message={error} onRetry={reload} />

  const courses = dashboard?.courses || []
  const attempts = dashboard?.recentQuizAttempts || []
  const continueCourse = dashboard?.continueCourse

  return (
    <>
      <PageHeading
        eyebrow={`${greeting().toUpperCase()} ${firstName.toUpperCase()} ✨`}
        title="Keep that curiosity going."
        description="Every lesson is a little step toward something bigger."
        action={
          <div className="date-pill">
            <CalendarDays size={16} /> Your learning space
          </div>
        }
      />

      <section className="welcome-banner">
        <div>
          <span className="banner-kicker">YOUR WEEKLY SPARK</span>
          <h2>
            Progress looks good
            <br />
            on you. <span>Keep going!</span>
          </h2>
          <p>
            You&apos;re showing up for your goals. That&apos;s worth celebrating.
          </p>
          {continueCourse ? (
            <Link
              to={`/student/course/${continueCourse.id}`}
              className="button button-light"
            >
              Continue {continueCourse.title} <ArrowRight size={17} />
            </Link>
          ) : (
            <Link to="/student/explore" className="button button-light">
              Explore courses <ArrowRight size={17} />
            </Link>
          )}
        </div>
        <div className="banner-illustration">
          <div className="banner-sun">🎯</div>
          <div className="banner-book">📘</div>
          <span className="banner-star star-a">✨</span>
          <span className="banner-star star-b">🌱</span>
        </div>
      </section>

      <div className="stats-grid">
        <div className="stat-card">
          <span className="stat-icon lilac">
            <BookOpen />
          </span>
          <div>
            <strong>{dashboard?.enrolledCourses ?? 0}</strong>
            <small>Courses joined</small>
          </div>
          <span className="stat-foot">Keep exploring</span>
        </div>
        <div className="stat-card">
          <span className="stat-icon peach">
            <Clock3 />
          </span>
          <div>
            <strong>{formatMinutes(dashboard?.learningMinutes)}</strong>
            <small>Learning time</small>
          </div>
          <span className="stat-foot">Time well spent</span>
        </div>
        <div className="stat-card">
          <span className="stat-icon mint">
            <Flame />
          </span>
          <div>
            <strong>{dashboard?.completedToday ?? 0}</strong>
            <small>Lessons today</small>
          </div>
          <span className="stat-foot">Build your streak</span>
        </div>
        <div className="stat-card">
          <span className="stat-icon yellow">
            <Trophy />
          </span>
          <div>
            <strong>{dashboard?.completedLessons ?? 0}</strong>
            <small>Lessons completed</small>
          </div>
          <span className="stat-foot">Little wins add up</span>
        </div>
      </div>

      <div className="section-row">
        <div>
          <h2>Pick up where you left off</h2>
          <p className="muted">Your learning journey is waiting.</p>
        </div>
        <Link to="/student/courses" className="text-link">
          All my courses <ArrowRight size={16} />
        </Link>
      </div>

      {courses.length ? (
        <div className="course-grid">
          {courses.slice(0, 2).map((course) => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
      ) : (
        <EmptyState
          title="You haven't joined a course yet"
          description="Browse the library and enroll in your first course."
          action={
            <Link to="/student/explore" className="button button-primary button-small">
              Explore courses <ArrowRight size={16} />
            </Link>
          }
        />
      )}

      <div className="section-row section-row-spaced">
        <div>
          <h2>A little goal for today</h2>
          <p className="muted">Small, steady steps make big things happen.</p>
        </div>
        <Link to="/student/progress" className="text-link">
          My progress <ArrowRight size={16} />
        </Link>
      </div>

      <div className="goal-card">
        <div className="goal-icon">
          <Target />
        </div>
        <div className="goal-copy">
          <strong>Complete one lesson today</strong>
          <span>You&apos;re just one play button away from progress.</span>
        </div>
        <div className="goal-progress">
          <strong>
            {dashboard?.dailyGoal?.completed ?? 0} /{' '}
            {dashboard?.dailyGoal?.target ?? 1}
          </strong>
          <small>daily goal</small>
        </div>
      </div>

      {attempts.length > 0 && (
        <>
          <div className="section-row section-row-spaced">
            <div>
              <h2>Recent quiz results</h2>
              <p className="muted">A quick look at your latest knowledge checks.</p>
            </div>
            <Link to="/student/quiz" className="text-link">
              All quizzes <ArrowRight size={16} />
            </Link>
          </div>
          <div className="quiz-result-list">
            {attempts.map((attempt) => (
              <div className="quiz-result-row" key={attempt.id}>
                <span className={`quiz-score ${attempt.passed ? 'pass' : 'fail'}`}>
                  {attempt.percentage}%
                </span>
                <div>
                  <strong>{attempt.quizTitle}</strong>
                  <span>{attempt.courseTitle}</span>
                </div>
                <small>{formatDate(attempt.submittedAt)}</small>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  )
}

function DiscoverCard({ course }) {
  const color = courseColor(course.id)
  const emoji = courseEmoji(course.category)

  return (
    <article className="course-card">
      <div className={`course-art ${color}`}>
        <span className="course-emoji">{emoji}</span>
        <span className="course-category">{course.category}</span>
        <span className="art-orbit orbit-one" />
        <span className="art-orbit orbit-two" />
      </div>
      <div className="course-card-body">
        <div className="course-meta">
          <span>{course.level}</span>
          <span>
            <Clock3 size={14} />
            {course.lessonCount} lesson
            {course.lessonCount === 1 ? '' : 's'}
          </span>
        </div>
        <h3>{course.title}</h3>
        <p className="muted small course-description">
          {course.description}
        </p>
        <p className="muted small">By {course.instructorName}</p>
        <Link className="card-link" to={`/student/course/${course.id}`}>
          View course <ArrowRight size={16} />
        </Link>
      </div>
    </article>
  )
}

export function StudentCourses() {
  const { data, loading, error, reload } = useApi(async () => {
    const [mine, explore] = await Promise.all([
      studentApi.courses(),
      courseApi.list()
    ])
    return {
      mine: mine.courses || [],
      explore: explore.courses || []
    }
  }, [])

  const [tab, setTab] = useState('mine')
  const [search, setSearch] = useState('')

  const enrolled = data?.mine || []
  const enrolledIds = useMemo(
    () => new Set(enrolled.map((course) => course.id)),
    [enrolled]
  )

  const explore = useMemo(() => {
    const term = search.trim().toLowerCase()
    const list = data?.explore || []
    if (!term) return list
    return list.filter((course) =>
      `${course.title} ${course.category} ${course.description}`
        .toLowerCase()
        .includes(term)
    )
  }, [data, search])

  if (loading) return <LoadingState message="Loading courses..." />
  if (error) return <ErrorState message={error} onRetry={reload} />

  return (
    <>
      <PageHeading
        eyebrow="YOUR LEARNING LIBRARY"
        title="My courses"
        description="All the things you're learning, in one place."
        action={
          <Link to="/student/explore" className="button button-primary">
            Explore courses <ArrowRight size={17} />
          </Link>
        }
      />

      <div className="tabs" role="tablist" aria-label="Course views">
        <button
          type="button"
          role="tab"
          aria-selected={tab === 'mine'}
          className={`tab-button ${tab === 'mine' ? 'active' : ''}`}
          onClick={() => setTab('mine')}
        >
          <BookOpen size={16} /> Enrolled ({enrolled.length})
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={tab === 'explore'}
          className={`tab-button ${tab === 'explore' ? 'active' : ''}`}
          onClick={() => setTab('explore')}
        >
          <Sparkles size={16} /> Discover
        </button>
      </div>

      {tab === 'mine' ? (
        enrolled.length ? (
          <div className="course-grid">
            {enrolled.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        ) : (
          <EmptyState
            title="No courses yet"
            description="Find a course that sparks your curiosity and enroll in one click."
            action={
              <button
                type="button"
                className="button button-primary button-small"
                onClick={() => setTab('explore')}
              >
                Browse the library <ArrowRight size={16} />
              </button>
            }
          />
        )
      ) : (
        <>
          <div className="toolbar">
            <label className="search-box">
              <Search size={17} />
              <input
                type="search"
                placeholder="Search courses, categories..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <span className="muted small">
              {explore.length} course{explore.length === 1 ? '' : 's'}
            </span>
          </div>

          {explore.length ? (
            <div className="course-grid">
              {explore.map((course) => (
                <div key={course.id} className="discover-wrap">
                  <DiscoverCard course={course} />
                  {enrolledIds.has(course.id) && (
                    <span className="enrolled-flag">Enrolled</span>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <EmptyState
              title="No matching courses"
              description="Try a different search term."
            />
          )}
        </>
      )}
    </>
  )
}

export function CourseDetails() {
  const { courseId } = useParams()
  const { data, loading, error, reload } = useApi(
    () => courseApi.get(courseId),
    [courseId]
  )

  const [enrolling, setEnrolling] = useState(false)
  const [enrollError, setEnrollError] = useState('')
  const [enrolledNow, setEnrolledNow] = useState(false)

  const course = data?.course
  const lessons = data?.lessons || []
  const quizzes = data?.quizzes || []

  if (loading) return <LoadingState message="Loading course..." />
  if (error) return <ErrorState message={error} onRetry={reload} />
  if (!course) return <ErrorState message="Course not found." />

  const completedCount = lessons.filter((lesson) => lesson.completed).length
  const progress = lessons.length
    ? clampPercent((completedCount / lessons.length) * 100)
    : 0
  const continueLesson =
    lessons.find(
      (lesson) => !lesson.completed && !lesson.isLocked
    ) || lessons.find((lesson) => !lesson.isLocked)

  async function handleEnroll() {
    setEnrolling(true)
    setEnrollError('')
    try {
      await courseApi.enroll(courseId)
      setEnrolledNow(true)
      reload()
    } catch (err) {
      setEnrollError(err.message)
    } finally {
      setEnrolling(false)
    }
  }

  return (
    <>
      <div className="back-row">
        <Link to="/student/courses">← Back to my courses</Link>
      </div>

      <div className="detail-hero">
        <div className={`detail-art ${courseColor(courseId)}`}>
          <span>{courseEmoji(course.category)}</span>
        </div>
        <div>
          <div className="eyebrow">
            {course.category} · {course.level}
          </div>
          <h1>{course.title}</h1>
          <p className="muted">Created by {course.instructorName}</p>
          <p>{course.description}</p>
          <div className="detail-meta">
            <span>
              <BookOpen size={16} /> {lessons.length} lesson
              {lessons.length === 1 ? '' : 's'}
            </span>
            <span>
              <Clock3 size={16} />{' '}
              {formatMinutes(
                lessons.reduce(
                  (total, lesson) => total + (lesson.durationMinutes || 0),
                  0
                )
              )}
            </span>
            {course.isEnrolled && (
              <span>
                <CheckCircle2 size={16} /> Enrolled
              </span>
            )}
          </div>

          <div className="detail-actions">
            {course.isEnrolled ? (
              continueLesson && (
                <Link
                  to={`/student/lesson/${courseId}?lesson=${continueLesson.id}`}
                  className="button button-primary"
                >
                  {progress > 0 ? 'Continue learning' : 'Start course'}{' '}
                  <Play size={16} />
                </Link>
              )
            ) : (
              <button
                type="button"
                className="button button-primary"
                onClick={handleEnroll}
                disabled={enrolling}
              >
                {enrolling ? 'Enrolling...' : 'Enroll in this course'}
                {!enrolling && <ArrowRight size={17} />}
              </button>
            )}

            {course.isEnrolled && lessons.length > 0 && (
              <div className="inline-progress">
                <span>
                  {completedCount} of {lessons.length} complete
                </span>
                <ProgressBar value={progress} />
              </div>
            )}
          </div>

          {enrolledNow && (
            <p className="success-message" role="status">
              You are enrolled. Pick a lesson below to begin.
            </p>
          )}
          {enrollError && (
            <p className="error-message" role="alert">
              {enrollError}
            </p>
          )}
          {!course.isEnrolled && lessons.some((lesson) => lesson.isPreview) && (
            <p className="muted small">
              Free preview lessons are available before you enroll.
            </p>
          )}
        </div>
      </div>

      <div className="section-row">
        <div>
          <h2>Course content</h2>
          <p className="muted">A simple path, one lesson at a time.</p>
        </div>
        <span className="muted small">
          {lessons.length} lesson{lessons.length === 1 ? '' : 's'}
        </span>
      </div>

      {lessons.length ? (
        <div className="lesson-list">
          {lessons.map((lesson, index) => (
            <div
              className={`lesson-row ${lesson.isLocked ? 'locked' : ''}`}
              key={lesson.id}
            >
              <span className="lesson-number">
                {lesson.completed ? (
                  <CheckCircle2 size={18} />
                ) : lesson.isLocked ? (
                  <Lock size={16} />
                ) : (
                  String(index + 1).padStart(2, '0')
                )}
              </span>
              <div>
                <strong>{lesson.title}</strong>
                <small>
                  {formatMinutes(lesson.durationMinutes)} ·{' '}
                  {lesson.hasVideo ? 'Video lesson' : 'Reading lesson'}
                  {lesson.isPreview && !course.isEnrolled ? ' · Preview' : ''}
                </small>
              </div>
              {lesson.isLocked ? (
                <span className="lesson-status">Enroll to unlock</span>
              ) : (
                <Link
                  className="lesson-action"
                  to={`/student/lesson/${courseId}?lesson=${lesson.id}`}
                >
                  {lesson.completed ? 'Rewatch' : 'Open'} <Play size={14} />
                </Link>
              )}
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          title="No lessons yet"
          description="The instructor is still preparing this course."
        />
      )}

      {course.isEnrolled && quizzes.length > 0 && (
        <>
          <div className="section-row section-row-spaced">
            <div>
              <h2>Knowledge checks</h2>
              <p className="muted">Short quizzes to see what you have picked up.</p>
            </div>
          </div>
          <div className="quiz-card-grid">
            {quizzes.map((quiz) => (
              <Link
                key={quiz.id}
                to={`/student/quiz?quiz=${quiz.id}`}
                className="quiz-card"
              >
                <span className="quiz-card-icon">
                  <ClipboardList size={20} />
                </span>
                <div>
                  <strong>{quiz.title}</strong>
                  <span>
                    {quiz.questionCount} question
                    {quiz.questionCount === 1 ? '' : 's'} · Pass at{' '}
                    {quiz.passingScore}%
                  </span>
                </div>
                <ArrowRight size={17} />
              </Link>
            ))}
          </div>
        </>
      )}
    </>
  )
}

export function LessonPlayer() {
  const { courseId } = useParams()
  const [searchParams, setSearchParams] = useSearchParams()
  const [completing, setCompleting] = useState(false)
  const [completeError, setCompleteError] = useState('')
  const [completedIds, setCompletedIds] = useState(new Set())
  const [videoError, setVideoError] = useState(false)

  const { data, loading, error, reload } = useApi(async () => {
    try {
      const result = await studentApi.lessons(courseId)
      return { ...result, enrolled: true }
    } catch (err) {
      if (err.status === 403) {
        const detail = await courseApi.get(courseId)
        return {
          course: detail.course,
          lessons: detail.lessons.filter((lesson) => !lesson.isLocked),
          enrolled: false
        }
      }
      throw err
    }
  }, [courseId])

  useEffect(() => {
    if (!data?.lessons) return
    setCompletedIds(
      new Set(
        data.lessons
          .filter((lesson) => lesson.completed)
          .map((lesson) => lesson.id)
      )
    )
  }, [data])

  useEffect(() => {
    setVideoError(false)
  }, [searchParams, data])

  const lessons = data?.lessons || []
  const course = data?.course
  const requestedId = searchParams.get('lesson')

  const selected =
    lessons.find((lesson) => lesson.id === requestedId) ||
    lessons.find((lesson) => !completedIds.has(lesson.id)) ||
    lessons[0]

  const selectedIndex = selected
    ? lessons.findIndex((lesson) => lesson.id === selected.id)
    : -1

  if (loading) return <LoadingState message="Loading lesson..." />
  if (error) return <ErrorState message={error} onRetry={reload} />
  if (!course) return <ErrorState message="Course not found." />
  if (!lessons.length) {
    return (
      <>
        <div className="back-row">
          <Link to={`/student/course/${courseId}`}>← Back to course</Link>
        </div>
        <EmptyState
          title="This course has no lessons yet"
          description="Check back soon — the instructor is still preparing content."
        />
      </>
    )
  }

  const completedCount = lessons.filter((lesson) =>
    completedIds.has(lesson.id)
  ).length
  const progress = lessons.length
    ? clampPercent((completedCount / lessons.length) * 100)
    : 0
  const isCompleted = selected ? completedIds.has(selected.id) : false

  function selectLesson(lessonId) {
    const next = new URLSearchParams(searchParams)
    next.set('lesson', lessonId)
    setSearchParams(next)
  }

  async function handleComplete() {
    if (!selected || isCompleted) return
    setCompleting(true)
    setCompleteError('')
    try {
      await lessonApi.complete(selected.id)
      setCompletedIds((current) => {
        const next = new Set(current)
        next.add(selected.id)
        return next
      })
    } catch (err) {
      setCompleteError(err.message)
    } finally {
      setCompleting(false)
    }
  }

  return (
    <>
      <div className="back-row">
        <Link to={`/student/course/${courseId}`}>← Back to course</Link>
      </div>

      {!data.enrolled && (
        <div className="notice-panel">
          <Sparkles size={18} />
          <div>
            <strong>You&apos;re viewing a free preview</strong>
            <span>
              <Link to={`/student/course/${courseId}`}>Enroll in this course</Link>{' '}
              to unlock every lesson and track your progress.
            </span>
          </div>
        </div>
      )}

      <div className="lesson-layout">
        <section className="lesson-main">
          {selected.videoStreamUrl ? (
            <div className="video-frame">
              <video
                key={selected.id}
                controls
                preload="metadata"
                poster=""
                src={authorizedVideoUrl(selected.videoStreamUrl)}
                onError={() => setVideoError(true)}
              >
                Your browser does not support video playback.
              </video>
            </div>
          ) : (
            <div className="video-empty">
              <Video size={28} />
              <strong>No video for this lesson</strong>
              <span>Read the lesson notes below, then mark it complete.</span>
            </div>
          )}

          {videoError && selected.videoStreamUrl && (
            <p className="error-message">
              This video could not be played here.{' '}
              <a
                href={authorizedVideoUrl(selected.videoStreamUrl)}
                target="_blank"
                rel="noreferrer"
              >
                Open it in a new tab
              </a>
              .
            </p>
          )}

          <div className="lesson-title-row">
            <div>
              <div className="eyebrow">
                LESSON {selectedIndex + 1} · {course.title}
              </div>
              <h1>{selected.title}</h1>
            </div>

            {data.enrolled ? (
              <button
                type="button"
                className={`button button-small ${
                  isCompleted ? 'button-outline' : 'button-primary'
                }`}
                onClick={handleComplete}
                disabled={completing || isCompleted}
              >
                <CheckCircle2 size={16} />
                {isCompleted
                  ? 'Completed'
                  : completing
                    ? 'Saving...'
                    : 'Mark complete'}
              </button>
            ) : (
              <Link
                to={`/student/course/${courseId}`}
                className="button button-primary button-small"
              >
                Enroll to track progress
              </Link>
            )}
          </div>

          {completeError && (
            <p className="error-message" role="alert">
              {completeError}
            </p>
          )}

          <p className="muted lesson-description">
            {selected.description ||
              'Welcome to this lesson. Follow along, take notes, and move to the next lesson when you are ready.'}
          </p>

          <div className="lesson-resource">
            <BookOpen size={19} />
            <div>
              <strong>Lesson notes</strong>
              <span>
                {selected.description ||
                  'Use this space to review the key ideas from the video.'}
              </span>
            </div>
          </div>

          <div className="lesson-nav">
            <button
              type="button"
              className="button button-outline button-small"
              disabled={selectedIndex <= 0}
              onClick={() => selectLesson(lessons[selectedIndex - 1].id)}
            >
              <ArrowLeft size={16} /> Previous
            </button>
            <button
              type="button"
              className="button button-outline button-small"
              disabled={selectedIndex >= lessons.length - 1}
              onClick={() => selectLesson(lessons[selectedIndex + 1].id)}
            >
              Next lesson <ArrowRight size={16} />
            </button>
          </div>
        </section>

        <aside className="lesson-playlist">
          <h3>Course content</h3>
          <p className="muted small">
            {completedCount} of {lessons.length} complete
          </p>
          <ProgressBar value={progress} />

          <div className="playlist-items">
            {lessons.map((lesson, index) => {
              const done = completedIds.has(lesson.id)
              return (
                <button
                  key={lesson.id}
                  type="button"
                  className={`playlist-item ${
                    selected.id === lesson.id ? 'selected' : ''
                  }`}
                  onClick={() => selectLesson(lesson.id)}
                >
                  <span>
                    {done ? <CheckCircle2 size={17} /> : <Play size={16} />}
                  </span>
                  <div>
                    <strong>
                      {index + 1}. {lesson.title}
                    </strong>
                    <small>
                      {formatMinutes(lesson.durationMinutes)}
                      {lesson.isPreview ? ' · Preview' : ''}
                    </small>
                  </div>
                </button>
              )
            })}
          </div>
        </aside>
      </div>
    </>
  )
}

function QuizRunner({ quizId, onBack }) {
  const { data, loading, error, reload } = useApi(
    () => quizApi.get(quizId),
    [quizId]
  )
  const [answers, setAnswers] = useState({})
  const [result, setResult] = useState(null)
  const [submitError, setSubmitError] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [secondsLeft, setSecondsLeft] = useState(null)
  const [timedOut, setTimedOut] = useState(false)
  const submittingRef = useRef(false)

  const quiz = data?.quiz
  const questionCount = quiz?.questions?.length || 0
  const answeredCount = Object.keys(answers).length

  useEffect(() => {
    if (!quiz?.timeLimitMinutes) {
      setSecondsLeft(null)
      return
    }
    setSecondsLeft(quiz.timeLimitMinutes * 60)
  }, [quiz])

  useEffect(() => {
    if (secondsLeft === null || result) return
    if (secondsLeft <= 0) return

    const timer = setInterval(() => {
      setSecondsLeft((current) => (current > 0 ? current - 1 : 0))
    }, 1000)

    return () => clearInterval(timer)
  }, [secondsLeft, result])

  async function handleSubmit(force = false) {
    if (submittingRef.current || result) return

    if (!force && answeredCount !== questionCount) {
      setSubmitError('Please answer every question before submitting.')
      return
    }

    submittingRef.current = true
    setSubmitting(true)
    setSubmitError('')

    try {
      const payload = Object.entries(answers).map(
        ([questionId, selectedOptionIndex]) => ({
          questionId,
          selectedOptionIndex
        })
      )
      const response = await quizApi.submit(quizId, payload)
      setResult(response.result)
    } catch (err) {
      setSubmitError(err.message)
    } finally {
      submittingRef.current = false
      setSubmitting(false)
    }
  }

  useEffect(() => {
    if (secondsLeft === 0 && quiz && !result && !submittingRef.current) {
      setTimedOut(true)
      handleSubmit(true)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [secondsLeft])

  if (loading) return <LoadingState message="Loading quiz..." />
  if (error) return <ErrorState message={error} onRetry={reload} />
  if (!quiz) return <ErrorState message="Quiz not found." />

  function reset() {
    setAnswers({})
    setResult(null)
    setSubmitError('')
    setTimedOut(false)
    setSecondsLeft(quiz.timeLimitMinutes ? quiz.timeLimitMinutes * 60 : null)
  }

  const minutes = secondsLeft !== null ? Math.floor(secondsLeft / 60) : 0
  const seconds = secondsLeft !== null ? secondsLeft % 60 : 0

  return (
    <>
      <div className="back-row">
        <button type="button" className="link-button" onClick={onBack}>
          ← Back to quizzes
        </button>
      </div>

      <PageHeading
        eyebrow={`KNOWLEDGE CHECK · ${quiz.courseTitle || ''}`}
        title={quiz.title}
        description={quiz.description || 'Answer each question and submit when ready.'}
        action={
          secondsLeft !== null && !result ? (
            <div className={`timer-pill ${secondsLeft <= 30 ? 'urgent' : ''}`}>
              <Clock3 size={16} />
              {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
            </div>
          ) : (
            <div className="date-pill">
              <Trophy size={16} /> Pass at {quiz.passingScore}%
            </div>
          )
        }
      />

      <div className="quiz-panel">
        <div className="quiz-top">
          <span>{questionCount} questions</span>
          <span>
            {answeredCount} answered
            {quiz.attemptsCount > 0
              ? ` · ${quiz.attemptsCount} previous attempt${
                  quiz.attemptsCount === 1 ? '' : 's'
                }`
              : ''}
          </span>
        </div>

        {quiz.questions.map((question, index) => (
          <div className="question-block" key={question.id}>
            <h3>
              <span>{String(index + 1).padStart(2, '0')}</span>
              {question.prompt}
            </h3>
            <div className="answer-list">
              {question.options.map((option, optionIndex) => (
                <button
                  key={`${question.id}-${optionIndex}`}
                  type="button"
                  disabled={Boolean(result) || submitting}
                  className={`answer-option ${
                    answers[question.id] === optionIndex ? 'chosen' : ''
                  }`}
                  onClick={() =>
                    setAnswers((current) => ({
                      ...current,
                      [question.id]: optionIndex
                    }))
                  }
                >
                  <span>{String.fromCharCode(65 + optionIndex)}</span>
                  {option}
                </button>
              ))}
            </div>
          </div>
        ))}

        {submitError && (
          <p className="error-message" role="alert">
            {submitError}
          </p>
        )}

        {result ? (
          <div
            className={`quiz-result ${result.passed ? '' : 'failed'}`}
            role="status"
          >
            {result.passed ? <Trophy size={22} /> : <Target size={22} />}
            <div>
              <strong>
                {result.passed ? 'You passed!' : 'Keep practising'} —{' '}
                {result.score}/{result.totalPoints} points ({result.percentage}%)
              </strong>
              <span>
                {timedOut
                  ? 'Time ran out, so your answers were submitted automatically. '
                  : ''}
                The passing score is {result.passingScore}%.
              </span>
            </div>
            <button
              type="button"
              className="button button-outline button-small"
              onClick={reset}
            >
              Try again
            </button>
          </div>
        ) : (
          <button
            type="button"
            className="button button-primary"
            disabled={
              submitting || answeredCount !== questionCount || !questionCount
            }
            onClick={() => handleSubmit(false)}
          >
            {submitting ? 'Submitting...' : 'Submit answers'}{' '}
            {!submitting && <ArrowRight size={17} />}
          </button>
        )}
      </div>
    </>
  )
}

export function QuizPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const quizId = searchParams.get('quiz')
  const { data, loading, error, reload } = useApi(studentApi.quizzes, [])

  if (quizId) {
    return (
      <QuizRunner
        quizId={quizId}
        onBack={() => {
          setSearchParams({})
          reload()
        }}
      />
    )
  }

  if (loading) return <LoadingState message="Loading quizzes..." />
  if (error) return <ErrorState message={error} onRetry={reload} />

  const quizzes = data?.quizzes || []
  const attempts = data?.attempts || []

  return (
    <>
      <PageHeading
        eyebrow="KNOWLEDGE CHECK"
        title="Quizzes"
        description="Take a moment to see what you've picked up."
      />

      {quizzes.length ? (
        <div className="quiz-card-grid">
          {quizzes.map((quiz) => (
            <button
              type="button"
              key={quiz.id}
              className="quiz-card quiz-card-button"
              onClick={() => setSearchParams({ quiz: quiz.id })}
            >
              <span className="quiz-card-icon">
                <ClipboardList size={20} />
              </span>
              <div>
                <strong>{quiz.title}</strong>
                <span>
                  {quiz.courseTitle} · {quiz.questionCount} question
                  {quiz.questionCount === 1 ? '' : 's'}
                </span>
                <span className="quiz-card-stats">
                  {quiz.attemptsCount > 0
                    ? `Best ${quiz.bestPercentage}% · ${quiz.attemptsCount} attempt${
                        quiz.attemptsCount === 1 ? '' : 's'
                      }`
                    : 'Not attempted yet'}
                  {quiz.lastPassed === true ? ' · Passed' : ''}
                  {quiz.lastPassed === false ? ' · Not passed yet' : ''}
                </span>
              </div>
              <ArrowRight size={17} />
            </button>
          ))}
        </div>
      ) : (
        <EmptyState
          title="No quizzes available"
          description="Enroll in a course that includes a knowledge check to see it here."
          action={
            <Link to="/student/explore" className="button button-primary button-small">
              Explore courses <ArrowRight size={16} />
            </Link>
          }
        />
      )}

      {attempts.length > 0 && (
        <>
          <div className="section-row section-row-spaced">
            <div>
              <h2>Attempt history</h2>
              <p className="muted">Every quiz attempt is saved to your progress.</p>
            </div>
          </div>
          <div className="table-panel">
            <div className="table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>Quiz</th>
                    <th>Score</th>
                    <th>Result</th>
                    <th>Submitted</th>
                  </tr>
                </thead>
                <tbody>
                  {attempts.map((attempt) => (
                    <tr key={attempt.id}>
                      <td>
                        <strong>{attempt.quizTitle || 'Quiz'}</strong>
                      </td>
                      <td>{attempt.percentage}%</td>
                      <td>
                        <span
                          className={`status-pill ${
                            attempt.passed ? 'pass' : 'fail'
                          }`}
                        >
                          {attempt.passed ? 'Passed' : 'Not passed'}
                        </span>
                      </td>
                      <td>{formatDateTime(attempt.submittedAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </>
  )
}

export function StudentProgress() {
  const { data, loading, error, reload } = useApi(studentApi.progress, [])

  if (loading) return <LoadingState message="Loading your progress..." />
  if (error) return <ErrorState message={error} onRetry={reload} />

  const summary = data?.summary || {}
  const courses = data?.courses || []
  const lessonProgress = data?.lessonProgress || []
  const attempts = data?.quizAttempts || []

  return (
    <>
      <PageHeading
        eyebrow="YOUR GROWTH, AT A GLANCE"
        title="Look how far you've come."
        description="Every completed lesson is proof that you're moving forward."
      />

      <div className="progress-summary">
        <div>
          <span className="eyebrow">OVERALL LEARNING PROGRESS</span>
          <strong>{summary.overallPercent ?? 0}%</strong>
          <p className="muted">
            {summary.completedLessons || 0} of {summary.totalLessons || 0} lessons
            complete across {summary.totalCourses || 0} course
            {summary.totalCourses === 1 ? '' : 's'}.
          </p>
        </div>
        <div className="big-progress">
          <ProgressBar value={summary.overallPercent ?? 0} />
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <span className="stat-icon lilac">
            <BookOpen />
          </span>
          <div>
            <strong>{summary.completedLessons ?? 0}</strong>
            <small>Lessons completed</small>
          </div>
        </div>
        <div className="stat-card">
          <span className="stat-icon peach">
            <ClipboardList />
          </span>
          <div>
            <strong>{summary.quizAttempts ?? 0}</strong>
            <small>Quiz attempts</small>
          </div>
        </div>
        <div className="stat-card">
          <span className="stat-icon mint">
            <Trophy />
          </span>
          <div>
            <strong>{summary.averageQuizScore ?? 0}%</strong>
            <small>Average quiz score</small>
          </div>
        </div>
        <div className="stat-card">
          <span className="stat-icon yellow">
            <Flame />
          </span>
          <div>
            <strong>{courses.filter((course) => course.progressPercent === 100).length}</strong>
            <small>Courses finished</small>
          </div>
        </div>
      </div>

      <div className="section-row">
        <div>
          <h2>Course progress</h2>
          <p className="muted">Your progress across all enrolled courses.</p>
        </div>
      </div>

      {courses.length ? (
        <div className="progress-course-list">
          {courses.map((course) => (
            <div className="progress-course" key={course.id}>
              <div className={`mini-course-art ${courseColor(course.id)}`}>
                {courseEmoji(course.category)}
              </div>
              <div className="progress-course-info">
                <strong>{course.title}</strong>
                <span>
                  {course.completedLessons} of {course.totalLessons} lessons
                </span>
                <ProgressBar value={course.progressPercent} />
              </div>
              <strong>{course.progressPercent}%</strong>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          title="No progress yet"
          description="Enroll in a course and complete your first lesson to see it here."
          action={
            <Link to="/student/explore" className="button button-primary button-small">
              Explore courses <ArrowRight size={16} />
            </Link>
          }
        />
      )}

      <div className="section-row section-row-spaced">
        <div>
          <h2>Recent lesson activity</h2>
          <p className="muted">The latest lessons you marked complete.</p>
        </div>
      </div>

      {lessonProgress.length ? (
        <div className="table-panel">
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>Lesson</th>
                  <th>Course</th>
                  <th>Status</th>
                  <th>Updated</th>
                </tr>
              </thead>
              <tbody>
                {lessonProgress.slice(0, 12).map((item) => (
                  <tr key={item.id}>
                    <td>
                      <strong>{item.lessonTitle}</strong>
                    </td>
                    <td>{item.courseTitle}</td>
                    <td>
                      <span
                        className={`status-pill ${item.completed ? 'pass' : 'neutral'}`}
                      >
                        {item.completed ? 'Completed' : 'In progress'}
                      </span>
                    </td>
                    <td>{formatDateTime(item.updatedAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <EmptyState
          title="No lesson activity yet"
          description="Complete a lesson to start building your history."
        />
      )}

      {attempts.length > 0 && (
        <>
          <div className="section-row section-row-spaced">
            <div>
              <h2>Quiz history</h2>
              <p className="muted">Scores are calculated securely by the server.</p>
            </div>
          </div>
          <div className="table-panel">
            <div className="table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>Quiz</th>
                    <th>Score</th>
                    <th>Result</th>
                    <th>Submitted</th>
                  </tr>
                </thead>
                <tbody>
                  {attempts.map((attempt) => (
                    <tr key={attempt.id}>
                      <td>
                        <strong>{attempt.quizTitle}</strong>
                        <small>{attempt.courseTitle}</small>
                      </td>
                      <td>
                        {attempt.score}/{attempt.totalPoints} ({attempt.percentage}%)
                      </td>
                      <td>
                        <span
                          className={`status-pill ${
                            attempt.passed ? 'pass' : 'fail'
                          }`}
                        >
                          {attempt.passed ? 'Passed' : 'Not passed'}
                        </span>
                      </td>
                      <td>{formatDateTime(attempt.submittedAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </>
  )
}
