const router = require('express').Router()
const { protect, allowRoles } = require('../middleware/auth')
const controller = require('../controllers/instructorController')
const asyncHandler = require('../utils/asyncHandler')

router.use(protect, allowRoles('instructor'))

router.get('/dashboard', asyncHandler(controller.dashboard))
router.get('/students', asyncHandler(controller.students))
router.get(
  '/courses/:courseId/lessons',
  asyncHandler(controller.courseLessons)
)

module.exports = router
