const express = require('express')
const cors = require('cors')
const helmet = require('helmet')
const morgan = require('morgan')
const { clientOrigins, nodeEnv } = require('./config/env')

const app = express()

app.disable('x-powered-by')
app.set('trust proxy', 1)

app.use(
  helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' }
  })
)

app.use(
  cors({
    origin(origin, callback) {
      // Allow server-to-server requests and tools such as curl/Postman.
      if (!origin) return callback(null, true)
      if (clientOrigins.includes(origin)) return callback(null, true)
      return callback(new Error('Origin is not allowed by API CORS policy.'))
    },
    methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Range'],
    exposedHeaders: ['Accept-Ranges', 'Content-Length', 'Content-Range'],
    credentials: false
  })
)

app.use(express.json({ limit: '1mb' }))
app.use(express.urlencoded({ extended: true, limit: '1mb' }))

if (nodeEnv !== 'test') {
  app.use(morgan(nodeEnv === 'production' ? 'combined' : 'dev'))
}

app.get('/', (_req, res) =>
  res.json({
    success: true,
    message: 'Learning Hub API',
    health: '/api/health'
  })
)

app.get('/api/health', (_req, res) =>
  res.json({
    success: true,
    message: 'Learning Hub API is running.',
    timestamp: new Date().toISOString()
  })
)

app.use('/api/auth', require('./routes/authRoutes'))
app.use('/api/courses', require('./routes/courseRoutes'))
app.use('/api/lessons', require('./routes/lessonRoutes'))
app.use('/api/quizzes', require('./routes/quizRoutes'))
app.use('/api/student', require('./routes/studentRoutes'))
app.use('/api/instructor', require('./routes/instructorRoutes'))

const errors = require('./middleware/errorHandler')

app.use(errors.notFound)
app.use(errors.errorHandler)

module.exports = app
