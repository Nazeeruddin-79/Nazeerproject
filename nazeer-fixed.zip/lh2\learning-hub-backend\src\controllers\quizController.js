const Course = require('../models/Course')
const Lesson = require('../models/Lesson')
const Quiz = require('../models/Quiz')
const Enrollment = require('../models/Enrollment')
const QuizAttempt = require('../models/QuizAttempt')
const { publicQuiz } = require('../utils/publicData')

async function ownsQuiz(quiz, userId) {
  const course = await Course.findById(quiz.course)
  return Boolean(course && String(course.instructor) === String(userId))
}

exports.create = async (req, res) => {
  const course = await Course.findOne({
    _id: req.params.courseId,
    instructor: req.user._id
  })

  if (!course) {
    return res.status(404).json({
      success: false,
      message: 'Course not found or not owned by you.'
    })
  }

  let lesson = null
  if (req.body.lessonId) {
    lesson = await Lesson.findOne({
      _id: req.body.lessonId,
      course: course._id
    })
    if (!lesson) {
      return res.status(400).json({
        success: false,
        message: 'Selected lesson does not belong to this course.'
      })
    }
  }

  const quiz = await Quiz.create({
    course: course._id,
    lesson: lesson?._id || null,
    title: req.body.title,
    description: req.body.description || '',
    timeLimitMinutes: req.body.timeLimitMinutes || 0,
    passingScore: req.body.passingScore ?? 60,
    questions: req.body.questions
  })

  res.status(201).json({
    success: true,
    quiz: { ...publicQuiz(quiz, { includeAnswers: true }), courseTitle: course.title }
  })
}

exports.mine = async (req, res) => {
  const courses = await Course.find({ instructor: req.user._id }).select('_id')
  const courseIds = courses.map((course) => course._id)

  const [quizzes, attemptRows] = await Promise.all([
    Quiz.find({ course: { $in: courseIds } })
      .populate('course', 'title')
      .sort({ createdAt: -1 }),
    courseIds.length
      ? QuizAttempt.aggregate([
          { $match: { course: { $in: courseIds } } },
          { $group: { _id: '$quiz', count: { $sum: 1 } } }
        ])
      : Promise.resolve([])
  ])

  const attemptMap = new Map(
    attemptRows.map((row) => [String(row._id), row.count])
  )

  res.json({
    success: true,
    quizzes: quizzes
      .filter((quiz) => quiz.course)
      .map((quiz) => ({
        ...publicQuiz(quiz, { includeAnswers: true }),
        courseTitle: quiz.course.title,
        attemptsCount: attemptMap.get(String(quiz._id)) || 0
      }))
  })
}

exports.update = async (req, res) => {
  const quiz = await Quiz.findById(req.params.quizId)

  if (!quiz || !(await ownsQuiz(quiz, req.user._id))) {
    return res.status(404).json({
      success: false,
      message: 'Quiz not found or not owned by you.'
    })
  }

  if (req.body.lessonId !== undefined) {
    if (!req.body.lessonId) {
      quiz.lesson = null
    } else {
      const lesson = await Lesson.findOne({
        _id: req.body.lessonId,
        course: quiz.course
      })
      if (!lesson) {
        return res.status(400).json({
          success: false,
          message: 'Selected lesson does not belong to this course.'
        })
      }
      quiz.lesson = lesson._id
    }
  }

  ;['title', 'description', 'timeLimitMinutes', 'passingScore', 'questions'].forEach(
    (field) => {
      if (req.body[field] !== undefined) quiz[field] = req.body[field]
    }
  )

  await quiz.save()
  res.json({ success: true, quiz: publicQuiz(quiz, { includeAnswers: true }) })
}

exports.remove = async (req, res) => {
  const quiz = await Quiz.findById(req.params.quizId)

  if (!quiz || !(await ownsQuiz(quiz, req.user._id))) {
    return res.status(404).json({
      success: false,
      message: 'Quiz not found or not owned by you.'
    })
  }

  await Promise.all([
    QuizAttempt.deleteMany({ quiz: quiz._id }),
    quiz.deleteOne()
  ])

  res.json({ success: true, message: 'Quiz deleted.' })
}

exports.get = async (req, res) => {
  const quiz = await Quiz.findById(req.params.quizId).populate(
    'course',
    'title instructor'
  )

  if (!quiz) {
    return res
      .status(404)
      .json({ success: false, message: 'Quiz not found.' })
  }

  const isOwner =
    req.user.role === 'instructor' &&
    String(quiz.course.instructor) === String(req.user._id)

  const isEnrolled =
    req.user.role === 'student' &&
    Boolean(
      await Enrollment.exists({
        student: req.user._id,
        course: quiz.course._id,
        status: { $in: ['active', 'completed'] }
      })
    )

  if (!isOwner && !isEnrolled) {
    return res.status(403).json({
      success: false,
      message: 'Enroll in this course to take the quiz.'
    })
  }

  const attempts = await QuizAttempt.find({
    student: req.user._id,
    quiz: quiz._id
  }).sort({ submittedAt: -1 })

  res.json({
    success: true,
    quiz: {
      ...publicQuiz(quiz, { includeAnswers: isOwner }),
      courseTitle: quiz.course.title,
      attemptsCount: attempts.length,
      lastAttempt: attempts[0]
        ? {
            id: String(attempts[0]._id),
            score: attempts[0].score,
            totalPoints: attempts[0].totalPoints,
            percentage: attempts[0].percentage,
            passed: attempts[0].passed,
            submittedAt: attempts[0].submittedAt
          }
        : null
    }
  })
}

exports.listForCourse = async (req, res) => {
  const enrolled = await Enrollment.exists({
    student: req.user._id,
    course: req.params.courseId,
    status: { $in: ['active', 'completed'] }
  })

  if (!enrolled) {
    return res.status(403).json({
      success: false,
      message: 'Enroll in this course to take its quizzes.'
    })
  }

  const quizzes = await Quiz.find({ course: req.params.courseId }).sort({
    createdAt: -1
  })

  res.json({
    success: true,
    quizzes: quizzes.map((quiz) => publicQuiz(quiz))
  })
}

exports.submit = async (req, res) => {
  const quiz = await Quiz.findById(req.params.quizId)

  if (!quiz) {
    return res
      .status(404)
      .json({ success: false, message: 'Quiz not found.' })
  }

  const enrolled = await Enrollment.exists({
    student: req.user._id,
    course: quiz.course,
    status: { $in: ['active', 'completed'] }
  })

  if (!enrolled) {
    return res.status(403).json({
      success: false,
      message: 'You are not enrolled in this course.'
    })
  }

  if (!Array.isArray(req.body.answers)) {
    return res
      .status(400)
      .json({ success: false, message: 'Answers must be an array.' })
  }

  const answerMap = new Map()

  for (const answer of req.body.answers) {
    if (
      !answer?.questionId ||
      !Number.isInteger(answer.selectedOptionIndex)
    ) {
      return res.status(400).json({
        success: false,
        message: 'Each answer needs questionId and selectedOptionIndex.'
      })
    }
    answerMap.set(String(answer.questionId), answer.selectedOptionIndex)
  }

  let score = 0
  const totalPoints = quiz.questions.reduce(
    (total, question) => total + question.points,
    0
  )
  const saved = []

  for (const question of quiz.questions) {
    const selected = answerMap.get(String(question._id))

    if (
      selected !== undefined &&
      (selected < 0 || selected >= question.options.length)
    ) {
      return res.status(400).json({
        success: false,
        message: 'An answer contains an invalid option.'
      })
    }

    if (selected === question.correctOptionIndex) score += question.points

    if (selected !== undefined) {
      saved.push({
        question: question._id,
        selectedOptionIndex: selected
      })
    }
  }

  const percentage = totalPoints
    ? Math.round((score / totalPoints) * 100)
    : 0
  const passed = percentage >= quiz.passingScore

  const attempt = await QuizAttempt.create({
    student: req.user._id,
    course: quiz.course,
    quiz: quiz._id,
    answers: saved,
    score,
    totalPoints,
    percentage,
    passed
  })

  res.status(201).json({
    success: true,
    message: 'Quiz submitted and scored.',
    result: {
      attemptId: String(attempt._id),
      score,
      totalPoints,
      percentage,
      passed,
      passingScore: quiz.passingScore
    }
  })
}

exports.attempts = async (req, res) => {
  const attempts = await QuizAttempt.find({ student: req.user._id })
    .populate('quiz', 'title')
    .populate('course', 'title')
    .sort({ submittedAt: -1 })

  res.json({
    success: true,
    attempts: attempts
      .filter((attempt) => attempt.quiz)
      .map((attempt) => ({
        id: String(attempt._id),
        quizTitle: attempt.quiz.title,
        courseTitle: attempt.course?.title || '',
        score: attempt.score,
        totalPoints: attempt.totalPoints,
        percentage: attempt.percentage,
        passed: attempt.passed,
        submittedAt: attempt.submittedAt
      }))
  })
}
