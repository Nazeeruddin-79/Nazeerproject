const router = require('express').Router()
const { z } = require('zod')
const controller = require('../controllers/quizController')
const { protect, allowRoles } = require('../middleware/auth')
const validate = require('../middleware/validate')
const asyncHandler = require('../utils/asyncHandler')

const question = z
  .object({
    prompt: z.string().trim().min(3).max(1000),
    options: z.array(z.string().trim().min(1).max(300)).min(2).max(6),
    correctOptionIndex: z.number().int().min(0),
    points: z.number().int().min(1).max(100).optional()
  })
  .refine((item) => item.correctOptionIndex < item.options.length, {
    message: 'Correct option index must point to an existing option.'
  })

const schema = z.object({
  title: z.string().trim().min(2).max(140),
  description: z.string().trim().max(2000).optional(),
  lessonId: z.string().optional(),
  timeLimitMinutes: z.coerce.number().min(0).max(300).optional(),
  passingScore: z.coerce.number().min(0).max(100).optional(),
  questions: z.array(question).min(1).max(100)
})

router.get(
  '/mine',
  protect,
  allowRoles('instructor'),
  asyncHandler(controller.mine)
)

router.get(
  '/attempts/mine',
  protect,
  allowRoles('student'),
  asyncHandler(controller.attempts)
)

router.get(
  '/course/:courseId',
  protect,
  allowRoles('student'),
  asyncHandler(controller.listForCourse)
)

router.post(
  '/course/:courseId',
  protect,
  allowRoles('instructor'),
  validate(schema),
  asyncHandler(controller.create)
)

router.get('/:quizId', protect, asyncHandler(controller.get))

router.post(
  '/:quizId/submit',
  protect,
  allowRoles('student'),
  asyncHandler(controller.submit)
)

router.patch(
  '/:quizId',
  protect,
  allowRoles('instructor'),
  validate(schema.partial()),
  asyncHandler(controller.update)
)

router.delete(
  '/:quizId',
  protect,
  allowRoles('instructor'),
  asyncHandler(controller.remove)
)

module.exports = router
