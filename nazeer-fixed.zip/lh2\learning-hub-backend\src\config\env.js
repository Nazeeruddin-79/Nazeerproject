const dotenv = require('dotenv')

dotenv.config()

const missing = ['MONGODB_URI', 'JWT_SECRET'].filter((key) => !process.env[key])
if (missing.length) {
  throw new Error(`Missing environment variables: ${missing.join(', ')}`)
}

if (process.env.JWT_SECRET.length < 32) {
  throw new Error('JWT_SECRET must be at least 32 characters.')
}

const nodeEnv = process.env.NODE_ENV || 'development'

module.exports = {
  nodeEnv,
  isProduction: nodeEnv === 'production',
  port: Number(process.env.PORT) || 5000,
  mongoUri: process.env.MONGODB_URI,
  jwtSecret: process.env.JWT_SECRET,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  clientOrigins: (process.env.CLIENT_ORIGIN || 'http://localhost:5173')
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean),
  uploadDir: process.env.UPLOAD_DIR || 'uploads/videos',
  maxVideoSizeBytes:
    (Number(process.env.MAX_VIDEO_SIZE_MB) || 500) * 1024 * 1024
}
