const multer = require('multer')
const path = require('path')
const fs = require('fs')
const os = require('os')
const crypto = require('crypto')
const { uploadDir, maxVideoSizeBytes } = require('../config/env')

// Vercel (and most serverless hosts) only allow writes to the OS temp folder.
const baseDir = process.env.VERCEL ? os.tmpdir() : process.cwd()
const absoluteUploadDir = path.resolve(baseDir, uploadDir)

fs.mkdirSync(absoluteUploadDir, { recursive: true })

const allowedMimeTypes = new Set([
  'video/mp4',
  'video/webm',
  'video/quicktime',
  'video/x-matroska',
  'application/octet-stream'
])

const allowedExtensions = new Set(['.mp4', '.webm', '.mov', '.mkv'])

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, absoluteUploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase()
    const safeExt = allowedExtensions.has(ext) ? ext : '.mp4'
    cb(null, `${Date.now()}-${crypto.randomBytes(8).toString('hex')}${safeExt}`)
  }
})

function fileFilter(_req, file, cb) {
  const ext = path.extname(file.originalname).toLowerCase()
  if (allowedMimeTypes.has(file.mimetype) && allowedExtensions.has(ext)) {
    return cb(null, true)
  }
  return cb(
    new Error('Unsupported video format. Use MP4, WebM, MOV, or MKV.')
  )
}

exports.absoluteUploadDir = absoluteUploadDir
exports.videoUpload = multer({
  storage,
  limits: { fileSize: maxVideoSizeBytes, files: 1 },
  fileFilter
}).single('video')
