const mongoose = require('mongoose')
const { mongoUri } = require('./env')

/**
 * Connect once and reuse the connection. This matters on Vercel, where many
 * invocations share the same warm container.
 */
module.exports = async function connectDatabase() {
  mongoose.set('strictQuery', true)

  if (mongoose.connection.readyState === 1) {
    return mongoose.connection
  }

  await mongoose.connect(mongoUri, {
    serverSelectionTimeoutMS: 15000,
    maxPoolSize: 10
  })

  console.log(`MongoDB connected: ${mongoose.connection.host}`)
  return mongoose.connection
}
