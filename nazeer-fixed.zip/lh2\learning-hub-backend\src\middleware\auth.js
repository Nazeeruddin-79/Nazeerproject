const jwt = require('jsonwebtoken')
const User = require('../models/User')
const { jwtSecret } = require('../config/env')
const asyncHandler = require('../utils/asyncHandler')

/**
 * Reads a JWT from the Authorization header, or from a `token` query
 * parameter. The query parameter is needed by <video src="..."> elements,
 * which cannot send custom headers.
 */
function readToken(req) {
  const [scheme, headerToken] = (req.headers.authorization || '').split(' ')
  if (scheme === 'Bearer' && headerToken) return headerToken
  if (typeof req.query.token === 'string' && req.query.token) {
    return req.query.token
  }
  return null
}

async function resolveUser(req) {
  const token = readToken(req)
  if (!token) return { error: 'Please sign in to continue.' }

  let payload
  try {
    payload = jwt.verify(token, jwtSecret)
  } catch {
    return { error: 'Your session is invalid or has expired.' }
  }

  const user = await User.findById(payload.sub)
  if (!user || !user.isActive) {
    return { error: 'This account is unavailable.' }
  }

  return { user }
}

exports.protect = asyncHandler(async (req, res, next) => {
  const { user, error } = await resolveUser(req)
  if (error) return res.status(401).json({ success: false, message: error })
  req.user = user
  next()
})

/**
 * Same as protect, but lets anonymous requests through. Used by public
 * course pages so signed-in students can see their enrollment status.
 */
exports.optionalAuth = asyncHandler(async (req, _res, next) => {
  req.user = null
  try {
    const { user } = await resolveUser(req)
    if (user) req.user = user
  } catch {
    // Ignore invalid sessions on public routes.
  }
  next()
})

exports.allowRoles =
  (...roles) =>
  (req, res, next) =>
    req.user && roles.includes(req.user.role)
      ? next()
      : res.status(403).json({
          success: false,
          message: 'You do not have permission to perform this action.'
        })
