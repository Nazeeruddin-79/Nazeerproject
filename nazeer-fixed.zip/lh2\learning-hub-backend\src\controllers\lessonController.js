const fs = require('fs')
const path = require('path')
const Course = require('../models/Course')
const Lesson = require('../models/Lesson')
const Enrollment = require('../models/Enrollment')
const LessonProgress = require('../models/LessonProgress')
const { absoluteUploadDir } = require('../middleware/upload')
const { publicLesson } = require('../utils/publicData')

function removeFile(filePath) {
  if (!filePath) return
  try {
    const resolved = path.resolve(filePath)
    if (!resolved.startsWith(absoluteUploadDir + path.sep)) return
    if (fs.existsSync(resolved)) fs.unlinkSync(resolved)
  } catch (error) {
    console.error('Could not delete video file:', error.message)
  }
}

async function isEnrolled(studentId, courseId) {
  return Boolean(
    await Enrollment.exists({
      student: studentId,
      course: courseId,
      status: { $in: ['active', 'completed'] }
    })
  )
}

async function hasAccess(user, lesson) {
  if (user.role === 'instructor') {
    return String(lesson.course.instructor) === String(user._id)
  }
  if (lesson.isPreview) return true
  return isEnrolled(user._id, lesson.course._id)
}

exports.create = async (req, res) => {
  const course = await Course.findOne({
    _id: req.params.courseId,
    instructor: req.user._id
  })

  if (!course) {
    if (req.file) removeFile(req.file.path)
    return res.status(404).json({
      success: false,
      message: 'Course not found or not owned by you.'
    })
  }

  const order = Number(req.body.order)

  if (await Lesson.exists({ course: course._id, order })) {
    if (req.file) removeFile(req.file.path)
    return res.status(409).json({
      success: false,
      message: `Lesson ${order} already exists in this course. Choose another order number.`
    })
  }

  const data = {
    course: course._id,
    title: req.body.title,
    description: req.body.description || '',
    order,
    durationMinutes: Number(req.body.durationMinutes) || 0,
    videoUrl: req.body.videoUrl || '',
    isPreview:
      req.body.isPreview === 'true' || req.body.isPreview === true
  }

  if (req.file) {
    Object.assign(data, {
      videoPath: req.file.path,
      videoMimeType: req.file.mimetype,
      videoOriginalName: req.file.originalname,
      videoSize: req.file.size
    })
  }

  const lesson = await Lesson.create(data)

  res.status(201).json({
    success: true,
    lesson: publicLesson(lesson, { includeVideo: true })
  })
}

exports.update = async (req, res) => {
  const lesson = await Lesson.findById(req.params.lessonId).populate('course')

  if (
    !lesson ||
    !lesson.course ||
    String(lesson.course.instructor) !== String(req.user._id)
  ) {
    if (req.file) removeFile(req.file.path)
    return res.status(404).json({
      success: false,
      message: 'Lesson not found or not owned by you.'
    })
  }

  if (req.body.order !== undefined) {
    const order = Number(req.body.order)
    const clash = await Lesson.exists({
      course: lesson.course._id,
      order,
      _id: { $ne: lesson._id }
    })
    if (clash) {
      if (req.file) removeFile(req.file.path)
      return res.status(409).json({
        success: false,
        message: `Lesson ${order} already exists in this course. Choose another order number.`
      })
    }
    lesson.order = order
  }

  ;['title', 'description', 'videoUrl'].forEach((field) => {
    if (req.body[field] !== undefined) lesson[field] = req.body[field]
  })

  if (req.body.durationMinutes !== undefined) {
    lesson.durationMinutes = Number(req.body.durationMinutes) || 0
  }

  if (req.body.isPreview !== undefined) {
    lesson.isPreview =
      req.body.isPreview === 'true' || req.body.isPreview === true
  }

  const previousVideo = lesson.videoPath

  if (req.file) {
    Object.assign(lesson, {
      videoPath: req.file.path,
      videoMimeType: req.file.mimetype,
      videoOriginalName: req.file.originalname,
      videoSize: req.file.size
    })
  }

  await lesson.save()

  if (req.file && previousVideo && previousVideo !== req.file.path) {
    removeFile(previousVideo)
  }

  res.json({
    success: true,
    lesson: publicLesson(lesson, { includeVideo: true })
  })
}

exports.remove = async (req, res) => {
  const lesson = await Lesson.findById(req.params.lessonId).populate('course')

  if (
    !lesson ||
    !lesson.course ||
    String(lesson.course.instructor) !== String(req.user._id)
  ) {
    return res.status(404).json({
      success: false,
      message: 'Lesson not found or not owned by you.'
    })
  }

  removeFile(lesson.videoPath)

  await Promise.all([
    LessonProgress.deleteMany({ lesson: lesson._id }),
    lesson.deleteOne()
  ])

  res.json({ success: true, message: 'Lesson deleted.' })
}

exports.get = async (req, res) => {
  const lesson = await Lesson.findById(req.params.lessonId).populate('course')

  if (!lesson) {
    return res
      .status(404)
      .json({ success: false, message: 'Lesson not found.' })
  }

  const allowed = await hasAccess(req.user, lesson)

  if (!allowed) {
    return res.status(403).json({
      success: false,
      message: 'Enroll in this course to watch this lesson.'
    })
  }

  res.json({
    success: true,
    lesson: publicLesson(lesson, { includeVideo: true })
  })
}

exports.stream = async (req, res) => {
  const lesson = await Lesson.findById(req.params.lessonId).populate('course')

  if (!lesson) {
    return res
      .status(404)
      .json({ success: false, message: 'Lesson not found.' })
  }

  const allowed = await hasAccess(req.user, lesson)

  if (!allowed) {
    return res.status(403).json({
      success: false,
      message: 'Enroll in this course to watch this lesson.'
    })
  }

  if (lesson.videoPath) {
    const file = path.resolve(lesson.videoPath)

    if (
      !file.startsWith(absoluteUploadDir + path.sep) ||
      !fs.existsSync(file)
    ) {
      if (lesson.videoUrl) return res.redirect(302, lesson.videoUrl)
      return res.status(404).json({
        success: false,
        message: 'Uploaded video is missing.'
      })
    }

    const stat = fs.statSync(file)
    const range = req.headers.range

    res.setHeader('Content-Type', lesson.videoMimeType || 'video/mp4')
    res.setHeader('Accept-Ranges', 'bytes')
    res.setHeader('Cache-Control', 'private, no-store')

    if (!range) {
      res.setHeader('Content-Length', stat.size)
      return fs.createReadStream(file).pipe(res)
    }

    const match = /^bytes=(\d*)-(\d*)$/.exec(range)

    if (!match || (!match[1] && !match[2])) {
      return res
        .status(416)
        .set('Content-Range', `bytes */${stat.size}`)
        .end()
    }

    let start
    let end

    if (!match[1]) {
      const suffixLength = Number(match[2])
      if (!Number.isFinite(suffixLength) || suffixLength <= 0) {
        return res
          .status(416)
          .set('Content-Range', `bytes */${stat.size}`)
          .end()
      }
      start = Math.max(0, stat.size - suffixLength)
      end = stat.size - 1
    } else {
      start = Number(match[1])
      end = match[2] ? Number(match[2]) : stat.size - 1
    }

    if (
      !Number.isInteger(start) ||
      !Number.isInteger(end) ||
      start < 0 ||
      start >= stat.size ||
      start > end
    ) {
      return res
        .status(416)
        .set('Content-Range', `bytes */${stat.size}`)
        .end()
    }

    end = Math.min(end, stat.size - 1)

    res.status(206).set({
      'Content-Range': `bytes ${start}-${end}/${stat.size}`,
      'Content-Length': end - start + 1
    })

    return fs.createReadStream(file, { start, end }).pipe(res)
  }

  if (lesson.videoUrl) return res.redirect(302, lesson.videoUrl)

  res.status(404).json({
    success: false,
    message: 'No video added to this lesson.'
  })
}

exports.complete = async (req, res) => {
  const lesson = await Lesson.findById(req.params.lessonId)

  if (!lesson) {
    return res
      .status(404)
      .json({ success: false, message: 'Lesson not found.' })
  }

  if (!(await isEnrolled(req.user._id, lesson.course))) {
    return res.status(403).json({
      success: false,
      message: 'You are not enrolled in this course.'
    })
  }

  const progress = await LessonProgress.findOneAndUpdate(
    { student: req.user._id, lesson: lesson._id },
    {
      $set: {
        course: lesson.course,
        completed: true,
        completedAt: new Date()
      },
      $setOnInsert: { student: req.user._id, lesson: lesson._id }
    },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  )

  const [totalLessons, completedLessons] = await Promise.all([
    Lesson.countDocuments({ course: lesson.course }),
    LessonProgress.countDocuments({
      student: req.user._id,
      course: lesson.course,
      completed: true
    })
  ])

  if (totalLessons > 0) {
    await Enrollment.updateOne(
      { student: req.user._id, course: lesson.course },
      {
        $set: {
          status:
            completedLessons >= totalLessons ? 'completed' : 'active'
        }
      }
    )
  }

  res.json({
    success: true,
    message: 'Lesson marked complete.',
    progress,
    courseProgress: {
      totalLessons,
      completedLessons,
      percent: totalLessons
        ? Math.round((completedLessons / totalLessons) * 100)
        : 0
    }
  })
}
