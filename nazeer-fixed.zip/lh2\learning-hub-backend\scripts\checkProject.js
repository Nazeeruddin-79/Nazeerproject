const fs = require('fs')

const required = [
  'index.js',
  'src/server.js',
  'src/app.js',
  'src/config/db.js',
  'src/config/env.js',
  'src/models/User.js',
  'src/models/Course.js',
  'src/models/Lesson.js',
  'src/models/Enrollment.js',
  'src/models/Quiz.js',
  'src/models/QuizAttempt.js',
  'src/models/LessonProgress.js',
  'src/controllers/authController.js',
  'src/controllers/courseController.js',
  'src/controllers/lessonController.js',
  'src/controllers/quizController.js',
  'src/controllers/studentController.js',
  'src/controllers/instructorController.js',
  'src/routes/authRoutes.js',
  'src/routes/courseRoutes.js',
  'src/routes/lessonRoutes.js',
  'src/routes/quizRoutes.js',
  'src/routes/studentRoutes.js',
  'src/routes/instructorRoutes.js'
]

const missing = required.filter((file) => !fs.existsSync(file))

if (missing.length) {
  console.error('Missing files:', missing.join(', '))
  process.exit(1)
}

console.log(`Structure check passed (${required.length} required files found).`)
