# LearnHub — Backend

REST API for the LearnHub React + Vite frontend.

## Stack

Node.js 20+, Express 4, MongoDB Atlas/Mongoose, JWT, bcryptjs, Zod validation, Multer video uploads, Helmet, CORS and rate limiting.

## Setup (PowerShell)

From the `learning-hub-backend` folder:

```powershell
npm install
Copy-Item .env.example .env
```

Open `.env` and fill in:

- `MONGODB_URI` — MongoDB Atlas connection string
- `JWT_SECRET` — at least 32 random characters
- `CLIENT_ORIGIN` — allowed frontend origin(s), comma separated

Keep `.env` private and never commit or share it.

### MongoDB Atlas

Create a cluster and database user, allow your development IP under Network Access, copy the Node.js connection string, and replace its placeholders in `.env`.

## Run

```powershell
npm run dev
```

API default: `http://localhost:5000`. Check `GET http://localhost:5000/api/health`.

## Seed demo data

Creates one instructor, one student, three published courses with lessons and quizzes, and two enrollments:

```powershell
npm run seed
```

Demo accounts:

| Role | Email | Password |
|---|---|---|
| Instructor | `instructor@learnhub.dev` | `TeachPass123!` |
| Student | `student@learnhub.dev` | `LearnPass123!` |

The script is safe to run more than once; it reuses existing demo accounts and courses.

## Create an instructor account

Public registration creates students only. Create additional instructors from the backend terminal:

```powershell
npm run create-instructor -- "Instructor Name" instructor@example.com "Use-A-Strong-Password!"
```

## Authentication

- `POST /api/auth/register` body: `{ "name": "Jamie Student", "email": "jamie@example.com", "password": "StrongPass123" }`
- `POST /api/auth/login` body: `{ "email": "jamie@example.com", "password": "StrongPass123", "role": "student" }`

`role` is optional; when supplied it must match the account. Both return `{ success, token, user }`. Send `Authorization: Bearer TOKEN` on protected requests. Passwords are bcrypt-hashed.

The video endpoint also accepts `?token=TOKEN` because a native `<video>` element cannot set an `Authorization` header. The token is still verified server-side.

## API route map

All paths are prefixed by `/api`.

| Method | Route | Access | Purpose |
|---|---|---|---|
| GET | `/health` | Public | API status |
| POST | `/auth/register` | Public | Register student |
| POST | `/auth/login` | Public | Student/instructor login |
| GET | `/auth/me` | Signed in | Current user |
| GET | `/courses` | Public | Browse published courses; optional `search`, `category`, `level` |
| GET | `/courses/:courseId` | Public | Course detail and lesson list |
| GET | `/courses/mine` | Instructor | Own courses with counts |
| POST | `/courses` | Instructor | Create course |
| PATCH | `/courses/:courseId` | Course owner | Update own course |
| DELETE | `/courses/:courseId` | Course owner | Delete course and related records |
| POST | `/courses/:courseId/enroll` | Student | Enroll in published course |
| POST | `/lessons/course/:courseId` | Course owner | Add lesson; optional multipart video |
| GET | `/lessons/:lessonId` | Signed in | Lesson metadata |
| GET | `/lessons/:lessonId/video` | Preview, enrolled student, or owner | Authorized video stream |
| PATCH | `/lessons/:lessonId` | Course owner | Update lesson/replace video |
| DELETE | `/lessons/:lessonId` | Course owner | Delete lesson |
| POST | `/lessons/:lessonId/complete` | Enrolled student | Mark lesson complete |
| POST | `/quizzes/course/:courseId` | Course owner | Create quiz |
| GET | `/quizzes/mine` | Instructor | Own quizzes |
| PATCH | `/quizzes/:quizId` | Quiz owner | Update quiz |
| DELETE | `/quizzes/:quizId` | Quiz owner | Delete quiz and attempts |
| GET | `/quizzes/course/:courseId` | Enrolled student | Quizzes for a course |
| GET | `/quizzes/:quizId` | Enrolled student or owner | Quiz questions without answers |
| POST | `/quizzes/:quizId/submit` | Enrolled student | Backend scoring |
| GET | `/quizzes/attempts/mine` | Student | Own quiz attempts |
| GET | `/student/dashboard` | Student | Dashboard summary |
| GET | `/student/courses` | Student | Enrolled courses/progress |
| GET | `/student/courses/:courseId/lessons` | Enrolled student | Lessons and completion |
| GET | `/student/progress` | Student | Own lesson progress and attempts |
| GET | `/student/quizzes` | Student | Quizzes for enrolled courses |
| GET | `/instructor/dashboard` | Instructor | Instructor statistics |
| GET | `/instructor/students` | Instructor | Students in own courses and quiz results |
| GET | `/instructor/courses/:courseId/lessons` | Course owner | Lessons and quizzes for one course |

### Course creation body

```json
{
  "title": "JavaScript Foundations",
  "description": "Learn JavaScript from the ground up.",
  "category": "Development",
  "level": "Beginner",
  "thumbnail": "",
  "status": "draft"
}
```

Publish by setting `status` to `published`.

### Lesson upload

Send `multipart/form-data` to `/lessons/course/:courseId` with an optional `video` file and the text fields `title`, `order`, `description`, `durationMinutes`, `videoUrl`, `isPreview`.

Supported MIME types: MP4, WebM, QuickTime/MOV, Matroska/MKV. Default maximum is 500 MB (`MAX_VIDEO_SIZE_MB`). Files are stored under `uploads/videos`. The API supports HTTP byte ranges for seeking.

On serverless hosts such as Vercel, uploads go to the OS temp folder and do not persist. Use external object storage for production.

### Quiz creation body

```json
{
  "title": "JavaScript Basics",
  "description": "Knowledge check",
  "timeLimitMinutes": 15,
  "passingScore": 60,
  "questions": [
    {
      "prompt": "Which keyword declares a block-scoped variable?",
      "options": ["var", "let", "print", "echo"],
      "correctOptionIndex": 1,
      "points": 1
    }
  ]
}
```

Student responses omit `correctOptionIndex`. Submission body:

```json
{ "answers": [{ "questionId": "QUESTION_SUBDOCUMENT_ID", "selectedOptionIndex": 1 }] }
```

Scoring is performed server-side.

## Database models

`User`, `Course`, `Lesson`, `Enrollment`, `Quiz`, `QuizAttempt`, `LessonProgress`.

## Deploying to Vercel

The root `index.js` exports a serverless handler and works with Vercel's zero-config Express support. `vercel.json` only sets the region.

Add these environment variables in the Vercel project:

- `MONGODB_URI`
- `JWT_SECRET`
- `CLIENT_ORIGIN` (your deployed frontend URL)
- `NODE_ENV=production`

## Production checklist

Use HTTPS, strong secrets, exact production CORS origins, MongoDB backups, persistent video storage, upload-size limits, and automated integration tests. Consider refresh-token rotation and revocation before a public launch.
