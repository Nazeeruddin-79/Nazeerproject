const fs = require('fs')
const path = require('path')
const Course = require('../models/Course')
const Lesson = require('../models/Lesson')
const Enrollment = require('../models/Enrollment')
const LessonProgress = require('../models/LessonProgress')
const Quiz = require('../models/Quiz')
const QuizAttempt = require('../models/QuizAttempt')
const { publicLesson, publicQuiz } = require('../utils/publicData')
const { absoluteUploadDir } = require('../middleware/upload')

function removeFile(filePath) {
  if (!filePath) return
  try {
    const resolved = path.resolve(filePath)
    if (!resolved.startsWith(absoluteUploadDir + path.sep)) return
    if (fs.existsSync(resolved)) fs.unlinkSync(resolved)
  } catch (error) {
    console.error('Could not delete video file:', error.message)
  }
}

function courseSummary(course) {
  return {
    id: String(course._id),
    title: course.title,
    description: course.description,
    category: course.category || 'General',
    level: course.level || 'Beginner',
    thumbnail: course.thumbnail || '',
    status: course.status || 'draft',
    instructorId: course.instructor?._id
      ? String(course.instructor._id)
      : String(course.instructor || ''),
    instructorName: course.instructor?.name || 'Learning Hub instructor',
    createdAt: course.createdAt,
    updatedAt: course.updatedAt
  }
}

async function lessonCounts(courseIds) {
  if (!courseIds.length) return new Map()
  const rows = await Lesson.aggregate([
    { $match: { course: { $in: courseIds } } },
    { $group: { _id: '$course', count: { $sum: 1 } } }
  ])
  return new Map(rows.map((row) => [String(row._id), row.count]))
}

async function studentCounts(courseIds) {
  if (!courseIds.length) return new Map()
  const rows = await Enrollment.aggregate([
    {
      $match: {
        course: { $in: courseIds },
        status: { $in: ['active', 'completed'] }
      }
    },
    { $group: { _id: '$course', count: { $sum: 1 } } }
  ])
  return new Map(rows.map((row) => [String(row._id), row.count]))
}

exports.list = async (req, res) => {
  const filter = { status: 'published' }
  if (req.query.category) filter.category = req.query.category
  if (req.query.level) filter.level = req.query.level

  if (req.query.search) {
    const search = String(req.query.search).slice(0, 100).trim()
    if (search) filter.$text = { $search: search }
  }

  const courses = await Course.find(filter)
    .populate('instructor', 'name')
    .sort({ createdAt: -1 })
    .lean()

  const counts = await lessonCounts(courses.map((course) => course._id))

  res.json({
    success: true,
    courses: courses.map((course) => ({
      ...courseSummary(course),
      lessonCount: counts.get(String(course._id)) || 0
    }))
  })
}

exports.get = async (req, res) => {
  const course = await Course.findOne({
    _id: req.params.courseId,
    status: 'published'
  }).populate('instructor', 'name')

  if (!course) {
    return res
      .status(404)
      .json({ success: false, message: 'Course not found.' })
  }

  const user = req.user
  const isOwner =
    user?.role === 'instructor' &&
    String(course.instructor?._id) === String(user._id)

  const isEnrolled =
    user?.role === 'student' &&
    Boolean(
      await Enrollment.exists({
        student: user._id,
        course: course._id,
        status: { $in: ['active', 'completed'] }
      })
    )

  const lessons = await Lesson.find({ course: course._id }).sort({ order: 1 })

  let completed = new Set()
  if (isEnrolled) {
    const progress = await LessonProgress.find({
      student: user._id,
      course: course._id,
      completed: true
    }).select('lesson')
    completed = new Set(progress.map((item) => String(item.lesson)))
  }

  const canWatchAll = isOwner || isEnrolled
  const quizzes =
    canWatchAll && user?.role === 'student'
      ? await Quiz.find({ course: course._id }).sort({ createdAt: -1 })
      : []

  res.json({
    success: true,
    course: {
      ...courseSummary(course),
      lessonCount: lessons.length,
      isEnrolled,
      isOwner
    },
    lessons: lessons.map((lesson) => {
      const locked = !canWatchAll && !lesson.isPreview
      return {
        ...publicLesson(lesson, { includeVideo: !locked, locked }),
        isLocked: locked,
        completed: completed.has(String(lesson._id))
      }
    }),
    quizzes: quizzes.map((quiz) => ({
      ...publicQuiz(quiz),
      courseTitle: course.title
    }))
  })
}

exports.mine = async (req, res) => {
  const courses = await Course.find({ instructor: req.user._id })
    .sort({ updatedAt: -1 })
    .lean()

  const ids = courses.map((course) => course._id)
  const [lessons, students, quizzes] = await Promise.all([
    lessonCounts(ids),
    studentCounts(ids),
    ids.length
      ? Quiz.aggregate([
          { $match: { course: { $in: ids } } },
          { $group: { _id: '$course', count: { $sum: 1 } } }
        ])
      : Promise.resolve([])
  ])
  const quizMap = new Map(quizzes.map((row) => [String(row._id), row.count]))

  res.json({
    success: true,
    courses: courses.map((course) => ({
      ...courseSummary(course),
      lessonCount: lessons.get(String(course._id)) || 0,
      studentCount: students.get(String(course._id)) || 0,
      quizCount: quizMap.get(String(course._id)) || 0
    }))
  })
}

exports.create = async (req, res) => {
  const course = await Course.create({
    ...req.body,
    instructor: req.user._id,
    status: req.body.status === 'published' ? 'published' : 'draft'
  })

  res.status(201).json({
    success: true,
    course: {
      ...courseSummary(course),
      lessonCount: 0,
      studentCount: 0,
      quizCount: 0
    }
  })
}

exports.update = async (req, res) => {
  const fields = [
    'title',
    'description',
    'category',
    'level',
    'thumbnail',
    'status'
  ]
  const updates = {}
  fields.forEach((field) => {
    if (req.body[field] !== undefined) updates[field] = req.body[field]
  })

  const course = await Course.findOneAndUpdate(
    { _id: req.params.courseId, instructor: req.user._id },
    updates,
    { new: true, runValidators: true }
  )

  if (!course) {
    return res.status(404).json({
      success: false,
      message: 'Course not found or not owned by you.'
    })
  }

  res.json({ success: true, course: courseSummary(course) })
}

exports.remove = async (req, res) => {
  const course = await Course.findOne({
    _id: req.params.courseId,
    instructor: req.user._id
  })

  if (!course) {
    return res.status(404).json({
      success: false,
      message: 'Course not found or not owned by you.'
    })
  }

  const lessons = await Lesson.find({ course: course._id })
  lessons.forEach((lesson) => removeFile(lesson.videoPath))

  await Promise.all([
    Lesson.deleteMany({ course: course._id }),
    Enrollment.deleteMany({ course: course._id }),
    LessonProgress.deleteMany({ course: course._id }),
    QuizAttempt.deleteMany({ course: course._id }),
    Quiz.deleteMany({ course: course._id }),
    course.deleteOne()
  ])

  res.json({
    success: true,
    message: 'Course and related learning records deleted.'
  })
}

exports.enroll = async (req, res) => {
  const course = await Course.findOne({
    _id: req.params.courseId,
    status: 'published'
  })

  if (!course) {
    return res.status(404).json({
      success: false,
      message: 'Published course not found.'
    })
  }

  let enrollment = await Enrollment.findOne({
    student: req.user._id,
    course: course._id
  })

  if (enrollment) {
    if (enrollment.status === 'cancelled') {
      enrollment.status = 'active'
      enrollment.enrolledAt = new Date()
      await enrollment.save()
    }
  } else {
    enrollment = await Enrollment.create({
      student: req.user._id,
      course: course._id,
      status: 'active'
    })
  }

  res.json({
    success: true,
    message: 'You are enrolled in this course.',
    enrollment
  })
}
