const Course = require('../models/Course')
const Lesson = require('../models/Lesson')
const Enrollment = require('../models/Enrollment')
const LessonProgress = require('../models/LessonProgress')
const Quiz = require('../models/Quiz')
const QuizAttempt = require('../models/QuizAttempt')
const { publicLesson } = require('../utils/publicData')

async function enrolledCourses(studentId) {
  const enrollments = await Enrollment.find({
    student: studentId,
    status: { $in: ['active', 'completed'] }
  })
    .populate('course')
    .sort({ enrolledAt: -1 })

  const courses = enrollments.filter((item) => item.course)
  const ids = courses.map((item) => item.course._id)

  if (!ids.length) return []

  const [lessonRows, progressRows] = await Promise.all([
    Lesson.aggregate([
      { $match: { course: { $in: ids } } },
      { $group: { _id: '$course', count: { $sum: 1 } } }
    ]),
    LessonProgress.aggregate([
      {
        $match: {
          student: studentId,
          completed: true,
          course: { $in: ids }
        }
      },
      { $group: { _id: '$course', count: { $sum: 1 } } }
    ])
  ])

  const lessonMap = new Map(
    lessonRows.map((row) => [String(row._id), row.count])
  )
  const progressMap = new Map(
    progressRows.map((row) => [String(row._id), row.count])
  )

  return courses.map(({ course, _id, enrolledAt, status }) => {
    const totalLessons = lessonMap.get(String(course._id)) || 0
    const completedLessons = progressMap.get(String(course._id)) || 0

    return {
      id: String(course._id),
      title: course.title,
      description: course.description,
      category: course.category || 'General',
      level: course.level || 'Beginner',
      thumbnail: course.thumbnail || '',
      enrollmentId: String(_id),
      enrolledAt,
      status,
      totalLessons,
      completedLessons,
      progressPercent: totalLessons
        ? Math.round((completedLessons / totalLessons) * 100)
        : 0
    }
  })
}

exports.courses = async (req, res) => {
  const courses = await enrolledCourses(req.user._id)
  res.json({ success: true, courses })
}

exports.dashboard = async (req, res) => {
  const courses = await enrolledCourses(req.user._id)

  const startOfToday = new Date()
  startOfToday.setHours(0, 0, 0, 0)

  const [quizAttemptCount, recentAttempts, completedToday, learningRows] =
    await Promise.all([
      QuizAttempt.countDocuments({ student: req.user._id }),
      QuizAttempt.find({ student: req.user._id })
        .populate('quiz', 'title')
        .populate('course', 'title')
        .sort({ submittedAt: -1 })
        .limit(5),
      LessonProgress.countDocuments({
        student: req.user._id,
        completed: true,
        completedAt: { $gte: startOfToday }
      }),
      LessonProgress.find({
        student: req.user._id,
        completed: true
      }).populate('lesson', 'durationMinutes')
    ])

  const totalLessons = courses.reduce(
    (total, course) => total + course.totalLessons,
    0
  )
  const completedLessons = courses.reduce(
    (total, course) => total + course.completedLessons,
    0
  )
  const learningMinutes = learningRows.reduce(
    (total, row) => total + (row.lesson?.durationMinutes || 0),
    0
  )

  res.json({
    success: true,
    dashboard: {
      enrolledCourses: courses.length,
      completedCourses: courses.filter((course) => course.progressPercent === 100)
        .length,
      completedLessons,
      totalLessons,
      overallPercent: totalLessons
        ? Math.round((completedLessons / totalLessons) * 100)
        : 0,
      learningMinutes,
      quizAttempts: quizAttemptCount,
      completedToday,
      dailyGoal: { target: 1, completed: Math.min(completedToday, 1) },
      continueCourse:
        courses.find((course) => course.progressPercent < 100) ||
        courses[0] ||
        null,
      courses: courses.slice(0, 4),
      recentQuizAttempts: recentAttempts
        .filter((attempt) => attempt.quiz)
        .map((attempt) => ({
          id: String(attempt._id),
          quizTitle: attempt.quiz.title,
          courseTitle: attempt.course?.title || '',
          percentage: attempt.percentage,
          passed: attempt.passed,
          submittedAt: attempt.submittedAt
        }))
    }
  })
}

exports.lessons = async (req, res) => {
  const course = await Course.findOne({
    _id: req.params.courseId,
    status: 'published'
  })

  if (!course) {
    return res
      .status(404)
      .json({ success: false, message: 'Course not found.' })
  }

  const enrolled = await Enrollment.exists({
    student: req.user._id,
    course: course._id,
    status: { $in: ['active', 'completed'] }
  })

  if (!enrolled) {
    return res.status(403).json({
      success: false,
      message: 'You are not enrolled in this course.'
    })
  }

  const [lessons, progress] = await Promise.all([
    Lesson.find({ course: course._id }).sort({ order: 1 }),
    LessonProgress.find({ student: req.user._id, course: course._id })
  ])

  const completed = new Set(
    progress
      .filter((item) => item.completed)
      .map((item) => String(item.lesson))
  )

  res.json({
    success: true,
    course: {
      id: String(course._id),
      title: course.title,
      category: course.category,
      level: course.level,
      description: course.description
    },
    lessons: lessons.map((lesson) => {
      const item = publicLesson(lesson, { includeVideo: true })
      return {
        ...item,
        isLocked: false,
        completed: completed.has(String(lesson._id))
      }
    })
  })
}

exports.progress = async (req, res) => {
  const courses = await enrolledCourses(req.user._id)

  const [lessonProgress, quizAttempts] = await Promise.all([
    LessonProgress.find({ student: req.user._id })
      .populate('lesson', 'title order durationMinutes')
      .populate('course', 'title')
      .sort({ updatedAt: -1 }),
    QuizAttempt.find({ student: req.user._id })
      .populate('quiz', 'title')
      .populate('course', 'title')
      .sort({ submittedAt: -1 })
  ])

  const totalLessons = courses.reduce(
    (total, course) => total + course.totalLessons,
    0
  )
  const completedLessons = courses.reduce(
    (total, course) => total + course.completedLessons,
    0
  )
  const averageQuizScore = quizAttempts.length
    ? Math.round(
        quizAttempts.reduce((total, attempt) => total + attempt.percentage, 0) /
          quizAttempts.length
      )
    : 0

  res.json({
    success: true,
    summary: {
      totalCourses: courses.length,
      totalLessons,
      completedLessons,
      overallPercent: totalLessons
        ? Math.round((completedLessons / totalLessons) * 100)
        : 0,
      quizAttempts: quizAttempts.length,
      averageQuizScore
    },
    courses,
    lessonProgress: lessonProgress
      .filter((item) => item.lesson && item.course)
      .map((item) => ({
        id: String(item._id),
        lessonTitle: item.lesson.title,
        courseTitle: item.course.title,
        completed: item.completed,
        completedAt: item.completedAt,
        updatedAt: item.updatedAt
      })),
    quizAttempts: quizAttempts
      .filter((attempt) => attempt.quiz)
      .map((attempt) => ({
        id: String(attempt._id),
        quizTitle: attempt.quiz.title,
        courseTitle: attempt.course?.title || '',
        score: attempt.score,
        totalPoints: attempt.totalPoints,
        percentage: attempt.percentage,
        passed: attempt.passed,
        submittedAt: attempt.submittedAt
      }))
  })
}

exports.quizzes = async (req, res) => {
  const enrollments = await Enrollment.find({
    student: req.user._id,
    status: { $in: ['active', 'completed'] }
  }).select('course')

  const courseIds = enrollments.map((item) => item.course)

  if (!courseIds.length) {
    return res.json({ success: true, quizzes: [], attempts: [] })
  }

  const [quizzes, attempts] = await Promise.all([
    Quiz.find({ course: { $in: courseIds } })
      .populate('course', 'title')
      .sort({ createdAt: -1 })
      .lean(),
    QuizAttempt.find({ student: req.user._id }).sort({ submittedAt: -1 }).lean()
  ])

  const attemptsByQuiz = new Map()
  attempts.forEach((attempt) => {
    const key = String(attempt.quiz)
    if (!attemptsByQuiz.has(key)) attemptsByQuiz.set(key, [])
    attemptsByQuiz.get(key).push(attempt)
  })

  res.json({
    success: true,
    quizzes: quizzes
      .filter((quiz) => quiz.course)
      .map((quiz) => {
        const quizAttempts = attemptsByQuiz.get(String(quiz._id)) || []
        const best = quizAttempts.reduce(
          (value, attempt) => Math.max(value, attempt.percentage),
          0
        )
        return {
          id: String(quiz._id),
          title: quiz.title,
          description: quiz.description || '',
          courseId: String(quiz.course._id),
          courseTitle: quiz.course.title,
          questionCount: quiz.questions.length,
          timeLimitMinutes: quiz.timeLimitMinutes || 0,
          passingScore: quiz.passingScore ?? 60,
          attemptsCount: quizAttempts.length,
          bestPercentage: best,
          lastPercentage: quizAttempts[0]?.percentage ?? null,
          lastPassed: quizAttempts[0]?.passed ?? null
        }
      }),
    attempts: attempts.map((attempt) => ({
      id: String(attempt._id),
      quizId: String(attempt.quiz),
      score: attempt.score,
      totalPoints: attempt.totalPoints,
      percentage: attempt.percentage,
      passed: attempt.passed,
      submittedAt: attempt.submittedAt
    }))
  })
}
