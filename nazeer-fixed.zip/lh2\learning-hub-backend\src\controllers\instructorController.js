const Course = require('../models/Course')
const Lesson = require('../models/Lesson')
const Enrollment = require('../models/Enrollment')
const LessonProgress = require('../models/LessonProgress')
const Quiz = require('../models/Quiz')
const QuizAttempt = require('../models/QuizAttempt')

exports.dashboard = async (req, res) => {
  const courses = await Course.find({ instructor: req.user._id })
    .select('_id title status category level')
    .sort({ updatedAt: -1 })
    .lean()

  const courseIds = courses.map((course) => course._id)

  const [
    lessonRows,
    studentRows,
    quizCount,
    quizAttemptCount,
    recentAttempts
  ] = await Promise.all([
    courseIds.length
      ? Lesson.aggregate([
          { $match: { course: { $in: courseIds } } },
          { $group: { _id: '$course', count: { $sum: 1 } } }
        ])
      : Promise.resolve([]),
    courseIds.length
      ? Enrollment.aggregate([
          {
            $match: {
              course: { $in: courseIds },
              status: { $in: ['active', 'completed'] }
            }
          },
          { $group: { _id: '$course', students: { $addToSet: '$student' } } }
        ])
      : Promise.resolve([]),
    courseIds.length
      ? Quiz.countDocuments({ course: { $in: courseIds } })
      : 0,
    courseIds.length
      ? QuizAttempt.countDocuments({ course: { $in: courseIds } })
      : 0,
    courseIds.length
      ? QuizAttempt.find({ course: { $in: courseIds } })
          .populate('student', 'name email')
          .populate('quiz', 'title')
          .populate('course', 'title')
          .sort({ submittedAt: -1 })
          .limit(6)
      : []
  ])

  const lessonMap = new Map(
    lessonRows.map((row) => [String(row._id), row.count])
  )
  const studentMap = new Map(
    studentRows.map((row) => [String(row._id), row.students.length])
  )
  const uniqueStudents = new Set(
    studentRows.flatMap((row) => row.students.map(String))
  )

  res.json({
    success: true,
    dashboard: {
      courseCount: courses.length,
      publishedCount: courses.filter((course) => course.status === 'published')
        .length,
      studentCount: uniqueStudents.size,
      lessonCount: lessonRows.reduce((total, row) => total + row.count, 0),
      quizCount,
      quizAttemptCount,
      courses: courses.map((course) => ({
        id: String(course._id),
        title: course.title,
        category: course.category || 'General',
        level: course.level || 'Beginner',
        status: course.status || 'draft',
        lessonCount: lessonMap.get(String(course._id)) || 0,
        studentCount: studentMap.get(String(course._id)) || 0
      })),
      recentAttempts: recentAttempts
        .filter((attempt) => attempt.student)
        .map((attempt) => ({
          id: String(attempt._id),
          studentName: attempt.student.name,
          studentEmail: attempt.student.email,
          quizTitle: attempt.quiz?.title || '',
          courseTitle: attempt.course?.title || '',
          percentage: attempt.percentage,
          passed: attempt.passed,
          submittedAt: attempt.submittedAt
        }))
    }
  })
}

exports.students = async (req, res) => {
  const courses = await Course.find({ instructor: req.user._id }).select('_id')
  const courseIds = courses.map((course) => course._id)

  if (!courseIds.length) {
    return res.json({
      success: true,
      students: [],
      quizResults: []
    })
  }

  const [enrollments, attempts, progressRows] = await Promise.all([
    Enrollment.find({
      course: { $in: courseIds },
      status: { $in: ['active', 'completed'] }
    })
      .populate('student', 'name email')
      .populate('course', 'title')
      .sort({ enrolledAt: -1 }),
    QuizAttempt.find({ course: { $in: courseIds } })
      .populate('student', 'name email')
      .populate('quiz', 'title')
      .populate('course', 'title')
      .sort({ submittedAt: -1 }),
    LessonProgress.aggregate([
      {
        $match: {
          course: { $in: courseIds },
          completed: true
        }
      },
      {
        $group: {
          _id: { student: '$student', course: '$course' },
          completed: { $sum: 1 }
        }
      }
    ])
  ])

  const lessonRows = await Lesson.aggregate([
    { $match: { course: { $in: courseIds } } },
    { $group: { _id: '$course', count: { $sum: 1 } } }
  ])
  const lessonTotals = new Map(
    lessonRows.map((row) => [String(row._id), row.count])
  )
  const progressMap = new Map(
    progressRows.map((row) => [
      `${row._id.student}-${row._id.course}`,
      row.completed
    ])
  )

  res.json({
    success: true,
    students: enrollments
      .filter((item) => item.student && item.course)
      .map((item) => {
        const total = lessonTotals.get(String(item.course._id)) || 0
        const completed =
          progressMap.get(`${item.student._id}-${item.course._id}`) || 0

        return {
          enrollmentId: String(item._id),
          studentId: String(item.student._id),
          name: item.student.name,
          email: item.student.email,
          courseId: String(item.course._id),
          courseTitle: item.course.title,
          enrolledAt: item.enrolledAt,
          status: item.status,
          completedLessons: completed,
          totalLessons: total,
          progressPercent: total ? Math.round((completed / total) * 100) : 0
        }
      }),
    quizResults: attempts
      .filter((attempt) => attempt.student)
      .map((attempt) => ({
        attemptId: String(attempt._id),
        studentName: attempt.student.name,
        studentEmail: attempt.student.email,
        courseTitle: attempt.course?.title || '',
        quizTitle: attempt.quiz?.title || '',
        score: attempt.score,
        totalPoints: attempt.totalPoints,
        percentage: attempt.percentage,
        passed: attempt.passed,
        submittedAt: attempt.submittedAt
      }))
  })
}

exports.courseLessons = async (req, res) => {
  const course = await Course.findOne({
    _id: req.params.courseId,
    instructor: req.user._id
  })

  if (!course) {
    return res.status(404).json({
      success: false,
      message: 'Course not found or not owned by you.'
    })
  }

  const [lessons, quizzes, enrollments] = await Promise.all([
    Lesson.find({ course: course._id }).sort({ order: 1 }),
    Quiz.find({ course: course._id }).sort({ createdAt: -1 }),
    Enrollment.countDocuments({
      course: course._id,
      status: { $in: ['active', 'completed'] }
    })
  ])

  res.json({
    success: true,
    course: {
      id: String(course._id),
      title: course.title,
      status: course.status,
      category: course.category,
      level: course.level,
      studentCount: enrollments
    },
    lessons: lessons.map((lesson) => ({
      id: String(lesson._id),
      title: lesson.title,
      description: lesson.description,
      order: lesson.order,
      durationMinutes: lesson.durationMinutes,
      isPreview: lesson.isPreview,
      hasVideo: Boolean(lesson.videoPath || lesson.videoUrl),
      videoOriginalName: lesson.videoOriginalName || '',
      videoSize: lesson.videoSize || 0,
      videoStreamUrl: `/api/lessons/${lesson._id}/video`
    })),
    quizzes: quizzes.map((quiz) => ({
      id: String(quiz._id),
      title: quiz.title,
      questionCount: quiz.questions.length,
      passingScore: quiz.passingScore
    }))
  })
}
