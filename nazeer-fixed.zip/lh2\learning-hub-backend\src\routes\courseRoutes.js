const router = require('express').Router()
const { z } = require('zod')
const controller = require('../controllers/courseController')
const { protect, optionalAuth, allowRoles } = require('../middleware/auth')
const validate = require('../middleware/validate')
const asyncHandler = require('../utils/asyncHandler')

const schema = z.object({
  title: z.string().trim().min(3).max(140),
  description: z.string().trim().min(10).max(5000),
  category: z.string().trim().max(60).optional(),
  level: z.enum(['Beginner', 'Intermediate', 'Advanced']).optional(),
  thumbnail: z.string().url().or(z.literal('')).optional(),
  status: z.enum(['draft', 'published']).optional()
})

router.get('/', asyncHandler(controller.list))

router.get(
  '/mine',
  protect,
  allowRoles('instructor'),
  asyncHandler(controller.mine)
)

router.post(
  '/',
  protect,
  allowRoles('instructor'),
  validate(schema),
  asyncHandler(controller.create)
)

router.get('/:courseId', optionalAuth, asyncHandler(controller.get))

router.patch(
  '/:courseId',
  protect,
  allowRoles('instructor'),
  validate(schema.partial()),
  asyncHandler(controller.update)
)

router.delete(
  '/:courseId',
  protect,
  allowRoles('instructor'),
  asyncHandler(controller.remove)
)

router.post(
  '/:courseId/enroll',
  protect,
  allowRoles('student'),
  asyncHandler(controller.enroll)
)

module.exports = router
