import { AlertCircle, Inbox } from 'lucide-react'

export function LoadingState({ message = 'Loading...' }) {
  return (
    <div className="state-panel" role="status">
      <div className="state-spinner" aria-hidden="true" />
      <p className="muted">{message}</p>
    </div>
  )
}

export function ErrorState({ message, onRetry }) {
  return (
    <div className="state-panel error" role="alert">
      <AlertCircle size={22} />
      <p>{message || 'Something went wrong.'}</p>
      {onRetry && (
        <button type="button" className="button button-outline button-small" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  )
}

export function EmptyState({ title, description, action }) {
  return (
    <div className="state-panel">
      <Inbox size={24} />
      <strong>{title}</strong>
      {description && <p className="muted">{description}</p>}
      {action}
    </div>
  )
}
