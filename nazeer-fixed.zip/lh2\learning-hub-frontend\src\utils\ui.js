export const COURSE_COLORS = ['lavender', 'peach', 'mint', 'blue']

export function courseColor(seed) {
  const value = String(seed || 'course')
  const total = value
    .split('')
    .reduce((sum, character) => sum + character.charCodeAt(0), 0)
  return COURSE_COLORS[total % COURSE_COLORS.length]
}

export function courseEmoji(category) {
  const value = String(category || '').toLowerCase()
  if (value.includes('design')) return '🎨'
  if (value.includes('data')) return '📊'
  if (value.includes('artificial') || value.includes('ai')) return '🤖'
  if (value.includes('business')) return '💼'
  if (value.includes('personal')) return '🌱'
  if (value.includes('development')) return '💻'
  if (value.includes('language')) return '🗣️'
  return '📚'
}

export function formatMinutes(minutes) {
  const value = Number(minutes) || 0
  if (value <= 0) return 'Self-paced'
  if (value < 60) return `${value} min`
  const hours = Math.floor(value / 60)
  const rest = value % 60
  return rest ? `${hours}h ${rest}m` : `${hours}h`
}

export function formatDate(value) {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return '—'
  return date.toLocaleDateString(undefined, {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  })
}

export function formatDateTime(value) {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return '—'
  return date.toLocaleString(undefined, {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit'
  })
}

export function clampPercent(value) {
  const numeric = Number(value)
  if (!Number.isFinite(numeric)) return 0
  return Math.min(100, Math.max(0, Math.round(numeric)))
}

export function greeting() {
  const hour = new Date().getHours()
  if (hour < 12) return 'Good morning'
  if (hour < 18) return 'Good afternoon'
  return 'Good evening'
}
